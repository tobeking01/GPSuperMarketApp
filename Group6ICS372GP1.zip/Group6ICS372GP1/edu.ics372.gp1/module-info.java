module edu.ics372.gp1 {
	exports edu.ics372.gp1.facade;
}