package edu.ics372.gp1.entities;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/** @author Group 6: Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
* @Copyright (c) 2022
* 
*            Redistribution and use with or without modification, are permitted
*            provided that the following conditions are met:
*
*            - the use is for academic purpose only - Redistributions of source
*            code must retain the above copyright notice, this list of
*            conditions and the following disclaimer. - Neither the name of
*            Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy. may be used to endorse or promote
*            products derived from this software without specific prior written
*            permission.
*
*            The authors do not make any claims regarding the correctness of
*            the code in this module and are not responsible for any loss or
*            damage resulting from its use.
*/

/**
 * DishWasher extends Product class representing a product of the Store.
 * 
 * @author Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
 *
 */

public class DishWasher extends Product implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final String DISH_WASHER_STRING = "DW";
	private static int idCounter;

	/**
	 * Creates a DishWasher with the given brandName, ModelName, price,
	 * monthlyPayment and a unique dishWasherId is created
	 * 
	 * @param brandName
	 * @param modelName
	 * @param price
	 */
	public DishWasher(String brandName, String modelName, double price) {
		super(brandName, modelName, price);
		productId = DISH_WASHER_STRING + ++idCounter;
	}

	@Override
	public String getBrandName() {
		return brandName;
	}

	@Override
	public String getModelName() {
		return modelName;
	}

	@Override
	public double getPrice() {
		return price;
	}

	@Override
	public String getProductId() {
		return this.productId;
	}

	@Override
	public int getCapacity() {
		return 0;
	}

	@Override
	public int getBTU() {
		return 0;
	}

	@Override
	public double getMonthlyRepairPlanCost() {
		return 0;
	}

	public static void save(ObjectOutputStream output) throws IOException {
		output.writeObject(idCounter);
	}

	public static void retrieve(ObjectInputStream input) throws IOException, ClassNotFoundException {
		idCounter = (int) input.readObject();
	}
}
