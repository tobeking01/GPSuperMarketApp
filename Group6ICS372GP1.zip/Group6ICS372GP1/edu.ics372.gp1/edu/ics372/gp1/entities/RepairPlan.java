package edu.ics372.gp1.entities;

import java.io.Serializable;

/** @author Group 4: Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
* @Copyright (c) 2022
* 
*            Redistribution and use with or without modification, are permitted
*            provided that the following conditions are met:
*
*            - the use is for academic purpose only - Redistributions of source
*            code must retain the above copyright notice, this list of
*            conditions and the following disclaimer. - Neither the name of
*            Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy. may be used to endorse or promote
*            products derived from this software without specific prior written
*            permission.
*
*            The authors do not make any claims regarding the correctness of
*            the code in this module and are not responsible for any loss or
*            damage resulting from its use.
*/

/**
 * RepairPlan for select products of the Store.
 * 
 * @author Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
 *
 */

public class RepairPlan implements Serializable {
	private static final long serialVersionUID = 1L;
	private String customerId;
	private String productId;
	private Product product;

	/**
	 * creates a repair plan with a customerId, productId and product
	 * 
	 * @param id
	 * @param productId
	 * @param product
	 */
	public RepairPlan(String id, String productId, Product product) {
		this.customerId = id;
		this.productId = productId;
		this.product = product;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	@Override
	public String toString() {
		return "[Brand: " + product.getBrandName() + ", Model: " + product.getModelName() + "]";
	}
}
