package edu.ics372.gp1.entities;

import java.io.Serializable;

/** @author Group 6: Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
* @Copyright (c) 2022
* 
*            Redistribution and use with or without modification, are permitted
*            provided that the following conditions are met:
*
*            - the use is for academic purpose only - Redistributions of source
*            code must retain the above copyright notice, this list of
*            conditions and the following disclaimer. - Neither the name of
*            Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy. may be used to endorse or promote
*            products derived from this software without specific prior written
*            permission.
*
*            The authors do not make any claims regarding the correctness of
*            the code in this module and are not responsible for any loss or
*            damage resulting from its use.
*/

/**
 * Product superclass for all product of the Store.
 * 
 * @author Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
 *
 */
public abstract class Product implements Serializable {

	private static final long serialVersionUID = 1L;
	protected String brandName;
	protected String modelName;
	protected double price;
	protected String productId;
	public int stock = 0;
	public int totalSold;

	/**
	 * creates a product with brandName, modelName and price
	 * 
	 * @param brandName
	 * @param modelName
	 * @param price
	 */
	public Product(String brandName, String modelName, double price) {
		this.brandName = brandName;
		this.modelName = modelName;
		this.price = price;
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object == null) {
			return false;
		}
		if (getClass() != object.getClass()) {
			return false;
		}
		Product other = (Product) object;
		if (productId == null) {
			if (other.productId != null) {
				return false;
			}
		} else if (!productId.equals(other.productId)) {
			return false;
		}
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((productId == null) ? 0 : productId.hashCode());
		return result;
	}

	public abstract String getBrandName();

	public abstract String getModelName();

	public abstract double getPrice();

	public abstract String getProductId();

	public abstract int getCapacity();

	public abstract int getBTU();

	public abstract double getMonthlyRepairPlanCost();

	public int getTotalSold() {
		return totalSold;
	}

	public void setTotalSold(int totalSold) {
		this.totalSold = totalSold;
	}

	public void addTotalSold(int quantity) {
		this.totalSold += quantity;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public void addStock(int quantity) {
		this.stock += quantity;
	}

	public void removeStock(int quantity) {
		this.stock -= quantity;
	}

	@Override
	public String toString() {
		return "Product [brandName=" + brandName + ", modelName=" + modelName + ", price=" + price + ", productId="
				+ productId + ", stock=" + stock + "]";
	}
}
