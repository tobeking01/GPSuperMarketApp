package edu.ics372.gp1.entities;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import edu.ics372.gp1.facade.Result;
import edu.ics372.gp1.iterators.FilteredIterator;
import edu.ics372.gp1.iterators.SafeTransactionIterator;

/** @author Group 6: Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
* @Copyright (c) 2022
* 
*            Redistribution and use with or without modification, are permitted
*            provided that the following conditions are met:
*
*            - the use is for academic purpose only - Redistributions of source
*            code must retain the above copyright notice, this list of
*            conditions and the following disclaimer. - Neither the name of
*            Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy. may be used to endorse or promote
*            products derived from this software without specific prior written
*            permission.
*
*            The authors do not make any claims regarding the correctness of
*            the code in this module and are not responsible for any loss or
*            damage resulting from its use.
*/

/**
 * Customer represents a customer of the Store.
 * 
 * @author Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
 *
 */

public class Customer implements Serializable {

	private static final long serialVersionUID = 1L;
	private String name;
	private String address;
	private String number;
	private String id;
	private static final String CUSTOMER_STRING = "C"; // Customer ID
	private static int idCounter; // id counter
	private List<Product> productPurchased = new LinkedList<Product>(); // list of product purchased for a customer
	private List<RepairPlan> repairPlans = new LinkedList<RepairPlan>(); // list of repair plan for a customer
	private List<Transaction> transactions = new LinkedList<Transaction>(); // list of transactions for a customer
	private double totalRepairPlansChargedRevenue;
	private double totalRepairPlansBalance;
	private int totalBackOrders;

	/**
	 * Create a single customer with the given name, address, number with a unique
	 * customerId created
	 * 
	 * @param name
	 * @param address
	 * @param number
	 */
	public Customer(String name, String address, String number) {
		this.name = name;
		this.address = address;
		this.number = number;
		id = CUSTOMER_STRING + ++idCounter;
	}

	/**
	 * enrollInRepairPlan method enrolls a customer in a repair plan
	 * 
	 * Only ClothDryer and ClothWasher products can be enrolled
	 * 
	 * @param product
	 * @return true or false
	 */
	public boolean enrollInRepairPlan(Product product) {
		if (product.getProductId().substring(0, 2).equals("CD") // Check if productId is ClothDryer
				|| product.getProductId().substring(0, 2).equals("CW")) { // check if productId is ClothWasher
			RepairPlan repairPlan;
			repairPlan = new RepairPlan(id, product.getProductId(), product); // create repair plan object using product
			repairPlans.add(repairPlan); // add to repair plan list
			totalRepairPlansBalance += repairPlan.getProduct().getMonthlyRepairPlanCost(); // calculate total repairPlan
			return true; // for a customer
		}
		return false;
	}

	/**
	 * withdrawFromRepairPlan removes a customer from a repairPlan
	 * 
	 * Only ClothDryer and ClothWasher products can be removed
	 * 
	 * @param product
	 * @return true or false
	 */
	public boolean withdrawFromRepairPlan(Product product) {
		if (product.getProductId().substring(0, 2).equals("CD") // Check if productId is ClothDryer
				|| product.getProductId().substring(0, 2).equals("CW")) {// check if productId is ClothWasher
			RepairPlan repairPlan;
			repairPlan = new RepairPlan(id, product.getProductId(), product);// create repair plan object using product

			for (Iterator<RepairPlan> repairPlans = getRepairPlansIterate(); repairPlans.hasNext();) { // for loop
																										// iterate over
																										// repair plans
				RepairPlan repairPlanIterate = repairPlans.next(); // while repair plan has next
				if (repairPlan.getCustomerId().equals(repairPlanIterate.getCustomerId()) // check if customer has repair
																							// plan using CustomerId
						&& repairPlan.getProductId().equals(repairPlanIterate.getCustomerId())) { // check if product
																									// has repair plan
																									// using productId
				}
				repairPlans.remove(); // remove from repair plan
				totalRepairPlansBalance -= repairPlan.getProduct().getMonthlyRepairPlanCost(); // calculate total
																								// repairPlan for a
																								// customer
				return true;
			}
		}
		return false;
	}

	/**
	 * chargeRepairPlan method charges all repair plans for a customer returns total
	 * repair plan revenue
	 */
	public void chargeRepairPlan() {
		Iterator<RepairPlan> iterator = repairPlans.iterator();
		while (iterator.hasNext()) {
			RepairPlan repairPlan = iterator.next();
			totalRepairPlansChargedRevenue += repairPlan.getProduct().getMonthlyRepairPlanCost();
		}
	}

	/**
	 * buyProduct method gets product, customer and quantity for a transaction
	 * 
	 * @param product
	 * @param customer
	 * @param quantity
	 * @return
	 */
	public Transaction buyProduct(Product product, Customer customer, int quantity) {
		int soldQuantity; // counts sold quantity
		int backOrderQuantity; // counts backOrder quantity
		double totalPrice; // counts total price
		int delivered; // counts delivered

		Transaction transaction = null; // reset transaction
		BackOrder backOrder = null; // reset backorder

		if (quantity <= product.getStock() && quantity > -1) { // check if product has stock and quantity
			soldQuantity = quantity; // send entered quantity to soldquantity
			delivered = soldQuantity; // send soldquantity to delivered
			product.removeStock(soldQuantity); // remove stock sold and from product count stock
			product.addTotalSold(soldQuantity); // get all products sold
			totalPrice = getTotalPrice(product, soldQuantity); // calculate the total price for quantity sold
			transaction = new Transaction("Purchased", product.getProductId(), quantity, null, totalPrice, delivered); // send
																														// the
																														// result
																														// to
																														// transaction

			transactions.add(transaction); // add to transaction

		}

		else if (quantity > product.getStock()) { // if all quantity not available
			soldQuantity = product.getStock(); // sold quantity holds all not sold
			backOrderQuantity = quantity - soldQuantity; // backorder holds what is left

			if ((product.getProductId().substring(0, 1)).equals("F")) {
				if (product.getStock() > 0) { // if not empty
					product.removeStock(soldQuantity); // remove soldQuantity from product stock
					product.addTotalSold(soldQuantity); // add product sold int
					delivered = soldQuantity; // total sold set to delivered
					totalPrice = getTotalPrice(product, soldQuantity); // totalprice gets product and soldQuantity
					transaction = new Transaction("Purchased", product.getProductId(), soldQuantity, null, totalPrice,
							delivered);// send result to transaction
					transactions.add(transaction); // add to transaction
				}
			} else if (!((product.getProductId().substring(0, 1)).equals("F"))) { // else // If not furnace
				product.removeStock(soldQuantity);
				product.addTotalSold(quantity);
				delivered = soldQuantity;
				totalBackOrders++;
				totalPrice = getTotalPrice(product, quantity);
				backOrder = new BackOrder(product.getBrandName(), product.getModelName(), customer.getName(), // send to
																												// backorder
						customer.getId(), backOrderQuantity, product.getProductId());
//				backOrders.add(backOrder);
				transaction = new Transaction("Purchased/BackOrdered", product.getProductId(), quantity, backOrder, // add
																													// to
																													// transaction
						totalPrice, delivered);
				transactions.add(transaction);
			} else
				return null;
		}
		return transaction; // return transaction
	}

	/**
	 * getTotalPrice helper method for buy product
	 * 
	 * @param product
	 * @param soldQuantity
	 * @return
	 */
	public double getTotalPrice(Product product, int soldQuantity) {
		return soldQuantity * product.getPrice();
	}

//	public boolean purchased(Product product) {
//		if (productPurchased.add(product)) {
//			transactions.add(new Transaction("Product", product.getBrandName(), product.getModelName()));
//			return true;
//		}
//		return false;
//	}

//	public Iterator<BackOrder> getBackorder() {
//		return backOrders.iterator();
//	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	public List<Product> getProductPurchased() {
		return productPurchased;
	}

	public void setProductPurchased(List<Product> productPurchased) {
		this.productPurchased = productPurchased;
	}

	public List<RepairPlan> getRepairPlans() {
		return repairPlans;
	}

	public void setRepairPlans(List<RepairPlan> repairPlans) {
		this.repairPlans = repairPlans;
	}

	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", address=" + address + ", number=" + number + ", id=" + id
				+ ", productPurchased=" + productPurchased + ", repairPlans=" + repairPlans + ", transactions="
				+ transactions + "]";
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return products
	 */
	public Iterator<Product> getPurchased() {
		return productPurchased.iterator();
	}

	/**
	 * @return repair plans
	 */
	public Iterator<RepairPlan> getRepairPlansIterate() {
		return repairPlans.iterator();
	}

	/**
	 * @return Transactions
	 */
	public Iterator<Transaction> getTransaction() {
		return transactions.iterator();
	}

	/**
	 * @param date
	 * @return Result
	 */
	public Iterator<Result> getTransactionsOnDate(GregorianCalendar date) {
		return new SafeTransactionIterator(
				new FilteredIterator(transactions.iterator(), transaction -> transaction.onDate(date)));
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * returns the total amount of revenue from a customer's repair plans
	 * 
	 * @return totalRepairPlansChargedRevenue
	 */
	public double getTotalRepairPlansChargedRevenue() {
		return totalRepairPlansChargedRevenue;
	}

	/**
	 * @param totalRepairPlansChargedRevenue
	 */
	public void setTotalRepairPlansChargedRevenue(double totalRepairPlansChargedRevenue) {
		this.totalRepairPlansChargedRevenue = totalRepairPlansChargedRevenue;
	}

	/**
	 * returns the current balance of a customer's repair plans
	 * 
	 * @return totalRepairPlansBalance
	 */
	public double getTotalRepairPlansBalance() {
		return totalRepairPlansBalance;
	}

	/**
	 * @param totalRepairPlansBalance
	 */
	public void setTotalRepairPlansBalance(double totalRepairPlansBalance) {
		this.totalRepairPlansBalance = totalRepairPlansBalance;
	}

	/**
	 * @param number the number to set
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * @param output
	 * @throws IOException
	 */
	public static void save(ObjectOutputStream output) throws IOException {
		output.writeObject(idCounter);
	}

	/**
	 * @param input
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public static void retrieve(ObjectInputStream input) throws IOException, ClassNotFoundException {
		idCounter = (int) input.readObject();
	}

	/**
	 * @return totalBackOrders
	 */
	public int getTotalBackOrders() {
		return totalBackOrders;
	}

	/**
	 * @param totalBackOrders
	 */
	public void setTotalBackOrders(int totalBackOrders) {
		this.totalBackOrders = totalBackOrders;
	}
}
