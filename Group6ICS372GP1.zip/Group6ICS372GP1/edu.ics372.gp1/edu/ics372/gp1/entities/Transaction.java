package edu.ics372.gp1.entities;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.GregorianCalendar;

/** @author Group 6: Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
* @Copyright (c) 2022
* 
*            Redistribution and use with or without modification, are permitted
*            provided that the following conditions are met:
*
*            - the use is for academic purpose only - Redistributions of source
*            code must retain the above copyright notice, this list of
*            conditions and the following disclaimer. - Neither the name of
*            Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy. may be used to endorse or promote
*            products derived from this software without specific prior written
*            permission.
*
*            The authors do not make any claims regarding the correctness of
*            the code in this module and are not responsible for any loss or
*            damage resulting from its use.
*/

/**
 * Transaction class for all transactions in the store.
 * 
 * @author Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
 *
 */

public class Transaction implements Serializable {

	private static final long serialVersionUID = 1L;
	private String type;
	private String productId;
	private int quantity;
	private GregorianCalendar date;
	private double totalPrice;
	private int delivered;
	private BackOrder backOrder;

	/**
	 * creates a transaction with transaction type, productId, quantity, backOrder
	 * and total price for a customer in the store
	 * 
	 * @param type
	 * @param productId
	 * @param quantity
	 * @param backOrder
	 * @param totalPrice
	 * @param delivered
	 */
	public Transaction(String type, String productId, int quantity, BackOrder backOrder, double totalPrice,
			int delivered) {
		this.type = type;
		this.productId = productId;
		this.quantity = quantity;
		this.totalPrice = totalPrice;
		this.backOrder = backOrder;
		this.delivered = delivered;
		date = new GregorianCalendar();
		fixMonthDate(date);
	}

	/**
	 * returns the Calendar date
	 * 
	 * @param date
	 * @return
	 */
	public boolean onDate(GregorianCalendar date) {
		return ((date.get(GregorianCalendar.YEAR) == this.date.get(GregorianCalendar.YEAR))
				&& (date.get(GregorianCalendar.MONTH) == this.date.get(GregorianCalendar.MONTH))
				&& (date.get(GregorianCalendar.DATE) == this.date.get(GregorianCalendar.DATE)));
	}

	/**
	 * Fixes the month of date
	 * 
	 * @param date
	 */
	public void fixMonthDate(GregorianCalendar date) {
		LocalDate today = LocalDate.now(ZoneId.of("America/Montreal"));
		date.set(GregorianCalendar.MONTH, today.getMonthValue());
	}

	/**
	 * Returns the date as a String
	 * 
	 * @return date with month, date, and year
	 */
	public String getDate() {
		return date.get(GregorianCalendar.MONTH) + "/" + date.get(GregorianCalendar.DATE) + "/"
				+ date.get(GregorianCalendar.YEAR);
	}

	/**
	 * @return the delivered
	 */
	public int getDelivered() {
		return delivered;
	}

	/**
	 * @param delivered the delivered to set
	 */
	public void setDelivered(int delivered) {
		this.delivered = delivered;
	}

	/**
	 * @return the totalPrice
	 */
	public double getTotalPrice() {
		return totalPrice;
	}

	/**
	 * @param totalPrice the totalPrice to set
	 */
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	/**
	 * @param backOrder the backOrder to set
	 */
	public void setBackOrder(BackOrder backOrder) {
		this.backOrder = backOrder;
	}

	public BackOrder getBackOrder() {
		return backOrder;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(GregorianCalendar date) {
		this.date = date;
	}
}
