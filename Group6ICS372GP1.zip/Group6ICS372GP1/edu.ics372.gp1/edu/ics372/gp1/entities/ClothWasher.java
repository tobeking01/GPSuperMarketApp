package edu.ics372.gp1.entities;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/** @author Group 6: Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
* @Copyright (c) 2022
* 
*            Redistribution and use with or without modification, are permitted
*            provided that the following conditions are met:
*
*            - the use is for academic purpose only - Redistributions of source
*            code must retain the above copyright notice, this list of
*            conditions and the following disclaimer. - Neither the name of
*            Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy. may be used to endorse or promote
*            products derived from this software without specific prior written
*            permission.
*
*            The authors do not make any claims regarding the correctness of
*            the code in this module and are not responsible for any loss or
*            damage resulting from its use.
*/

/**
 * ClothWasher extends Product class representing a product of the Store.
 * 
 * @author Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
 *
 */

public class ClothWasher extends Product implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final String CLOTH_WASHER_STRING = "CW";
	private static int idCounter;
	private RepairPlan repairPlan;
	private double monthlyRepairPlanCost;

	/**
	 * Creates a ClothWasher with the given brandName, ModelName, price,
	 * monthlyPayment and a unique clothWasherId is created
	 * 
	 * @param brandName
	 * @param modelName
	 * @param price
	 * @param monthlyPayment
	 */
	public ClothWasher(String brandName, String modelName, double price, double monthlyPayment) {
		super(brandName, modelName, price);
		productId = CLOTH_WASHER_STRING + ++idCounter;
		this.monthlyRepairPlanCost = monthlyPayment;
	}

	@Override
	public String getBrandName() {
		return brandName;
	}

	@Override
	public String getModelName() {
		return modelName;
	}

	@Override
	public double getPrice() {
		return price;
	}

	public RepairPlan getRepairPlan() {
		return repairPlan;
	}

	public void setRepairPlan(RepairPlan repairPlan) {
		this.repairPlan = repairPlan;
	}

	public double getMonthlyRepairPlanCost() {
		return monthlyRepairPlanCost;
	}

	public void setMonthlyRepairPlanCost(double monthlyPayment) {
		this.monthlyRepairPlanCost = monthlyPayment;
	}

	public String getProductId() {
		return this.productId;
	}

	@Override
	public int getCapacity() {
		return 0;
	}

	@Override
	public int getBTU() {
		return 0;
	}

	public static void save(ObjectOutputStream output) throws IOException {
		output.writeObject(idCounter);
	}

	public static void retrieve(ObjectInputStream input) throws IOException, ClassNotFoundException {
		idCounter = (int) input.readObject();
	}

}
