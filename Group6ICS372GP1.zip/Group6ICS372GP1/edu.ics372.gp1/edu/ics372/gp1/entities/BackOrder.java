package edu.ics372.gp1.entities;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/** @author Group 6: Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
* @Copyright (c) 2022
* 
*            Redistribution and use with or without modification, are permitted
*            provided that the following conditions are met:
*
*            - the use is for academic purpose only - Redistributions of source
*            code must retain the above copyright notice, this list of
*            conditions and the following disclaimer. - Neither the name of
*            Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy. may be used to endorse or promote
*            products derived from this software without specific prior written
*            permission.
*
*            The authors do not make any claims regarding the correctness of
*            the code in this module and are not responsible for any loss or
*            damage resulting from its use.
*/

/**
 * BackOrder represents all backOrders of customers in the store
 * 
 * @author Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
 *
 */

public class BackOrder implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final String BACK_ORDER_STRING = "BO";
	private static int idCounter;
	private String backOrderId;
	private String productId;
	private String backOrderBrandName;
	private String backOrderModelName;
	private String backOrderCustomerName;
	private String backOrderCustomerId;
	private int backOrderQuantity;

	public BackOrder(String brandName, String modelName, String customerName, String customerId, int quantity,
			String productId) {
		backOrderId = BACK_ORDER_STRING + ++idCounter;
		this.backOrderBrandName = brandName;
		this.backOrderModelName = modelName;
		this.backOrderCustomerName = customerName;
		this.backOrderCustomerId = customerId;
		this.backOrderQuantity = quantity;
		this.productId = productId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getBackOrderBrandName() {
		return backOrderBrandName;
	}

	public void setBackOrderBrandName(String backOrderBrandName) {
		this.backOrderBrandName = backOrderBrandName;
	}

	public String getBackOrderModelName() {
		return backOrderModelName;
	}

	public void setBackOrderModelName(String backOrderModelName) {
		this.backOrderModelName = backOrderModelName;
	}

	public String getBackOrderCustomerName() {
		return backOrderCustomerName;
	}

	public void setBackOrderCustomerName(String backOrderCustomerName) {
		this.backOrderCustomerName = backOrderCustomerName;
	}

	public String getBackOrderCustomerId() {
		return backOrderCustomerId;
	}

	public void setBackOrderCustomerId(String backOrderCustomerId) {
		this.backOrderCustomerId = backOrderCustomerId;
	}

	public int getBackOrderQuantity() {
		return backOrderQuantity;
	}

	public void setBackOrderQuantity(int backOrderQuantity) {
		this.backOrderQuantity = backOrderQuantity;
	}

	public String getBackOrderId() {
		return backOrderId;
	}

	public void setBackOrderId(String backOrderId) {
		this.backOrderId = backOrderId;
	}

	public static void save(ObjectOutputStream output) throws IOException {
		output.writeObject(idCounter);
	}

	public static void retrieve(ObjectInputStream input) throws IOException, ClassNotFoundException {
		idCounter = (int) input.readObject();
	}
}
