package edu.ics372.gp1.facade;

import java.util.LinkedList;
import java.util.List;

import edu.ics372.gp1.entities.BackOrder;
import edu.ics372.gp1.entities.Customer;
import edu.ics372.gp1.entities.Product;
import edu.ics372.gp1.entities.RepairPlan;
import edu.ics372.gp1.entities.Transaction;

/** @author Group 6: Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
* @Copyright (c) 2022
* 
*            Redistribution and use with or without modification, are permitted
*            provided that the following conditions are met:
*
*            - the use is for academic purpose only - Redistributions of source
*            code must retain the above copyright notice, this list of
*            conditions and the following disclaimer. - Neither the name of
*            Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy. may be used to endorse or promote
*            products derived from this software without specific prior written
*            permission.
*
*            The authors do not make any claims regarding the correctness of
*            the code in this module and are not responsible for any loss or
*            damage resulting from its use.
*/

/**
 * The DataTransfer class is used to facilitate data transfer between store and
 * UserInterface. It is also used to support iterating over customer and product
 * objects. The class stores copies of fields that may be sent in either
 * direction.
 * 
 * @author Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
 *
 */

public abstract class DataTransfer {
	private String productId;
	private String brandName;
	private String modelName;
	private int btu;
	private int capacity;
	private int stock;
	private int purchaseQuantity;
	private int totalSold;

	private double price;
	private double monthlyRepairPlanCost;
	private String purchasedBy;
	private String purchaseDate;

	private String customerId;
	private String customerName;
	private String customerAddress;
	private String customerNumber;
	private BackOrder customerBackOrder;
	private List<RepairPlan> repairPlans = new LinkedList<RepairPlan>();
	private double totalRepairPlansChargedRevenue;
	private double totalRepairPlansBalance;
	private int customerTotalBackOrders;

	private String transactionType;
	private String transactionBrandName;
	private String transactionModelName;
	private String transactionProductId;
	private int transactionQuantity;
	private int transactionDelivered;
	private double transactionTotalPrice;
	private BackOrder transactionBackOrder;
	private String transactionDate;

	private String backOrderId;
	private String backOrderBrandName;
	private String backOrderModelName;
	private String backOrderCustomerName;
	private String backOrderCustomerId;
	private int backOrderQuantity;

	public DataTransfer() {
		reset();
	}

	public double getTotalRepairPlansChargedRevenue() {
		return totalRepairPlansChargedRevenue;
	}

	public void setTotalRepairPlansChargedRevenue(double totalRepairPlansChargedRevenue) {
		this.totalRepairPlansChargedRevenue = totalRepairPlansChargedRevenue;
	}

	public double getTotalRepairPlansBalance() {
		return totalRepairPlansBalance;
	}

	public void setTotalRepairPlansBalance(double totalRepairPlansBalance) {
		this.totalRepairPlansBalance = totalRepairPlansBalance;
	}

	public int getTotalSold() {
		return totalSold;
	}

	public void setTotalSold(int totalSold) {
		this.totalSold = totalSold;
	}

	public List<RepairPlan> getRepairPlans() {
		return repairPlans;
	}

	public void setRepairPlans(List<RepairPlan> repairPlans) {
		this.repairPlans = repairPlans;
	}

	public String getBackOrderId() {
		return backOrderId;
	}

	public void setBackOrderId(String backOrderId) {
		this.backOrderId = backOrderId;
	}

	public int getBackOrderQuantity() {
		return backOrderQuantity;
	}

	public void setBackOrderQuantity(int backOrderQuantity) {
		this.backOrderQuantity = backOrderQuantity;
	}

	public int getTransactionDelivered() {
		return transactionDelivered;
	}

	public void setTransactionDelivered(int transactionDelivered) {
		this.transactionDelivered = transactionDelivered;
	}

	public void setTransactionTotalPrice(double transactionTotalPrice) {
		this.transactionTotalPrice = transactionTotalPrice;
	}

	public double getTransactionTotalPrice() {
		return transactionTotalPrice;
	}

	public void setTransactionTotalPrice(int transactionTotalPrice) {
		this.transactionTotalPrice = transactionTotalPrice;
	}

	public int getTransactionQuantity() {
		return transactionQuantity;
	}

	public void setTransactionQuantity(int transactionQuantity) {
		this.transactionQuantity = transactionQuantity;
	}

	public String getTransactionProductId() {
		return transactionProductId;
	}

	public void setTransactionProductId(String transactionProductId) {
		this.transactionProductId = transactionProductId;
	}

	public int getPurchaseQuantity() {
		return purchaseQuantity;
	}

	public void setPurchaseQuantity(int purchaseQuantity) {
		this.purchaseQuantity = purchaseQuantity;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the brandName
	 */
	public String getBrandName() {
		return brandName;
	}

	/**
	 * @param brandName the brandName to set
	 */
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	/**
	 * @return the btu
	 */
	public int getBtu() {
		return btu;
	}

	public double getMonthlyRepairPlanCost() {
		return monthlyRepairPlanCost;
	}

	public void setMonthlyRepairPlanCost(double monthlyPayment) {
		this.monthlyRepairPlanCost = monthlyPayment;
	}

	/**
	 * @param btu the btu to set
	 */
	public void setBtu(int btu) {
		this.btu = btu;
	}

	/**
	 * @return the capacity
	 */
	public int getCapacity() {
		return capacity;
	}

	/**
	 * @param capacity the capacity to set
	 */
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	/**
	 * @return the modelName
	 */
	public String getModelName() {
		return modelName;
	}

	/**
	 * @param modelName the modelName to set
	 */
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	/**
	 * @return the purchasedBy
	 */
	public String getPurchasedBy() {
		return purchasedBy;
	}

	/**
	 * @param purchasedBy the purchasedBy to set
	 */
	public void setPurchasedBy(String purchasedBy) {
		this.purchasedBy = purchasedBy;
	}

	/**
	 * @return the purchaseDate
	 */
	public String getPurchaseDate() {
		return purchaseDate;
	}

	/**
	 * @param purchaseDate the purchaseDate to set
	 */
	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the customerAddress
	 */
	public String getCustomerAddress() {
		return customerAddress;
	}

	/**
	 * @param customerAddress the customerAddress to set
	 */
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	/**
	 * @return the customerNumber
	 */
	public String getCustomerNumber() {
		return customerNumber;
	}

	/**
	 * @param customerNumber the customerNumber to set
	 */
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	public void setCustomerBackOrder(BackOrder backOrder) {
		this.customerBackOrder = backOrder;
	}

	public BackOrder getCustomerBackOrder() {
		return customerBackOrder;
	}

	public int getCustomerTotalBackOrders() {
		return customerTotalBackOrders;
	}

	public void setCustomerTotalBackOrders(int customerTotalBackOrders) {
		this.customerTotalBackOrders = customerTotalBackOrders;
	}

	public String getBackOrderBrandName() {
		return backOrderBrandName;
	}

	public void setBackOrderBrandName(String backOrderBrandName) {
		this.backOrderBrandName = backOrderBrandName;
	}

	public String getBackOrderModelName() {
		return backOrderModelName;
	}

	public void setBackOrderModelName(String backOrderModelName) {
		this.backOrderModelName = backOrderModelName;
	}

	public String getBackOrderCustomerName() {
		return backOrderCustomerName;
	}

	public void setBackOrderCustomerName(String backOrderCustomerName) {
		this.backOrderCustomerName = backOrderCustomerName;
	}

	public String getBackOrderCustomerId() {
		return backOrderCustomerId;
	}

	public void setBackOrderCustomerId(String backOrderCustomerId) {
		this.backOrderCustomerId = backOrderCustomerId;
	}

	public BackOrder getTransactionBackOrder() {
		return transactionBackOrder;
	}

	public void setTransactionBackOrder(BackOrder transactionBackOrder) {
		this.transactionBackOrder = transactionBackOrder;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	/**
	 * @return the transactionType
	 */
	public String getTransactionType() {
		return transactionType;
	}

	/**
	 * @param transactionType the transactionType to set
	 */
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	/**
	 * @return the transactionDate
	 */
	public String getTransactionDate() {
		return transactionDate;
	}

	/**
	 * @param transactionDate the transactionDate to set
	 */
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	/**
	 * @return the transactionBrandName
	 */
	public String getTransactionBrandName() {
		return transactionBrandName;
	}

	/**
	 * @param transactionBrandName the transactionBrandName to set
	 */
	public void setTransactionBrandName(String transactionBrandName) {
		this.transactionBrandName = transactionBrandName;
	}

	/**
	 * @return the transactionModelName
	 */
	public String getTransactionModelName() {
		return transactionModelName;
	}

	/**
	 * @param transactionModelName the transactionModelName to set
	 */
	public void setTransactionModelName(String transactionModelName) {
		this.transactionModelName = transactionModelName;
	}

	/**
	 * Sets all the Product-related fields using the Product parameter.
	 * 
	 * @param product
	 */
	public void setProductFields(Product product) {
		productId = product.getProductId();
		brandName = product.getBrandName();
		modelName = product.getModelName();
		price = product.getPrice();
		monthlyRepairPlanCost = product.getMonthlyRepairPlanCost();
		btu = product.getBTU();
		capacity = product.getCapacity();
		stock = product.getStock();
		totalSold = product.getTotalSold();
	}

	/**
	 * Sets all the Customer-related fields using the Customer parameter.
	 * 
	 * @param customer
	 */
	public void setCustomerFields(Customer customer) {
		customerId = customer.getId();
		customerName = customer.getName();
		customerAddress = customer.getAddress();
		customerNumber = customer.getNumber();
		repairPlans = customer.getRepairPlans();
		totalRepairPlansChargedRevenue = customer.getTotalRepairPlansChargedRevenue();
		totalRepairPlansBalance = customer.getTotalRepairPlansBalance();
		setCustomerTotalBackOrders(customer.getTotalBackOrders());
	}

	/**
	 * Sets all the Transaction-related fields using the Transaction parameter.
	 * 
	 * @param transaction
	 */
	public void setTransactionFields(Transaction transaction) {
		transactionType = transaction.getType();
		transactionProductId = transaction.getProductId();
		transactionDate = transaction.getDate();
		transactionBackOrder = transaction.getBackOrder();
		transactionQuantity = transaction.getQuantity();
		transactionTotalPrice = transaction.getTotalPrice();
		transactionDelivered = transaction.getDelivered();
		if (transactionBackOrder != null) {
			setBackOrderFields(transactionBackOrder);
			setCustomerBackOrder(transactionBackOrder);
		}
	}

	/**
	 * Sets all the BackOrder-related fields using the BackOrder parameter.
	 * 
	 * @param backOrder
	 */
	public void setBackOrderFields(BackOrder backOrder) {
		backOrderId = backOrder.getBackOrderId();
		backOrderBrandName = backOrder.getBackOrderBrandName();
		backOrderModelName = backOrder.getBackOrderModelName();
		backOrderCustomerName = backOrder.getBackOrderCustomerName();
		backOrderCustomerId = backOrder.getBackOrderCustomerId();
		backOrderQuantity = backOrder.getBackOrderQuantity();
	}

	/**
	 * Sets all String fields to "none"
	 */
	private void reset() {
		productId = "Invalid product id";
		brandName = "No such brand name";
		modelName = "No such model Name";
		price = 0;
		monthlyRepairPlanCost = 0;
		stock = 0;
		btu = 0;
		capacity = 0;
		purchasedBy = "Not purchased";
		purchaseDate = "Not applicable (not purchased)";
		customerId = "Invalid customerId";
		customerName = "No such customer";
		customerAddress = "No such customer";
		customerNumber = "No such customer";

	}
}