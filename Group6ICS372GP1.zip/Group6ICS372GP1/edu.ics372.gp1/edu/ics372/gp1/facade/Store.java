package edu.ics372.gp1.facade;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;

import edu.ics372.gp1.collections.BackOrderList;
import edu.ics372.gp1.collections.Catalog;
import edu.ics372.gp1.collections.CustomerList;
import edu.ics372.gp1.entities.BackOrder;
import edu.ics372.gp1.entities.ClothDryer;
import edu.ics372.gp1.entities.ClothWasher;
import edu.ics372.gp1.entities.Customer;
import edu.ics372.gp1.entities.DishWasher;
import edu.ics372.gp1.entities.Furnace;
import edu.ics372.gp1.entities.KitchenRange;
import edu.ics372.gp1.entities.Product;
import edu.ics372.gp1.entities.Refrigerator;
import edu.ics372.gp1.entities.Transaction;
import edu.ics372.gp1.iterators.SafeBackOrderIterator;
import edu.ics372.gp1.iterators.SafeCustomerIterator;
import edu.ics372.gp1.iterators.SafeProductIterator;
import edu.ics372.gp1.tests.AutomatedTester;

/** @author Group 4: Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
* @Copyright (c) 2022
* 
*            Redistribution and use with or without modification, are permitted
*            provided that the following conditions are met:
*
*            - the use is for academic purpose only - Redistributions of source
*            code must retain the above copyright notice, this list of
*            conditions and the following disclaimer. - Neither the name of
*            Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy. may be used to endorse or promote
*            products derived from this software without specific prior written
*            permission.
*
*            The authors do not make any claims regarding the correctness of
*            the code in this module and are not responsible for any loss or
*            damage resulting from its use.
*/

/**
 * Store is main facade class handling all requests from users.
 * 
 * @author Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
 *
 */

public class Store implements Serializable {

	private static final long serialVersionUID = 1L;
	private Catalog catalog = Catalog.getInstance();
	private CustomerList customers = CustomerList.getInstance();
	private BackOrderList backOrders = BackOrderList.getInstance();
	private static Store store;

	/**
	 * Singleton Catalog
	 */
	private Store() {
	}

	public static Store instance() {
		if (store == null) {
			return store = new Store();
		} else {
			return store;
		}
	}

	/**
	 * Organizes the operations for adding ClothDryer
	 * 
	 * @param BrandName             clothDryer BrandName
	 * @param modelName             clothDryer modelName
	 * @param price                 clothDryer price
	 * @param MonthlyRepairPlanCost clothDryer MonthlyRepairPlanCost
	 * @return the clothDryer object created
	 */
	public Result addClothDryer(Request request) {
		Result result = new Result();
		ClothDryer clothDryer = new ClothDryer(request.getBrandName(), request.getModelName(), request.getPrice(),
				request.getMonthlyRepairPlanCost());
		if (catalog.insertProduct(clothDryer)) {
			result.setResultCode(Result.OPERATION_COMPLETED);
			result.setProductFields(clothDryer);
			return result;
		}
		result.setResultCode(Result.OPERATION_FAILED);
		return result;
	}

	/**
	 * Organizes the operations for adding clothWasher
	 * 
	 * @param BrandName             clothWasher BrandName
	 * @param modelName             clothWasher modelName
	 * @param price                 clothWasher price
	 * @param MonthlyRepairPlanCost clothWasher MonthlyRepairPlanCost
	 * @return the clothWasher object created
	 */
	public Result addClothWasher(Request request) {
		Result result = new Result();
		Product clothWasher = new ClothWasher(request.getBrandName(), request.getModelName(), request.getPrice(),
				request.getMonthlyRepairPlanCost());
		if (catalog.insertProduct(clothWasher)) {
//			System.out.println(clothWasher.productId);
			result.setResultCode(Result.OPERATION_COMPLETED);
			result.setProductFields(clothWasher);
			return result;
		}
		result.setResultCode(Result.OPERATION_FAILED);
		return result;
	}

	/**
	 * Organizes the operations for adding dishWasher
	 * 
	 * @param BrandName dishWasher BrandName
	 * @param modelName dishWasher modelName
	 * @param price     dishWasher price
	 * @return the dishWasher object created
	 */
	public Result addDishWasher(Request request) {
		Result result = new Result();
		Product dishWasher = new DishWasher(request.getBrandName(), request.getModelName(), request.getPrice());
		if (catalog.insertProduct(dishWasher)) {
			result.setResultCode(Result.OPERATION_COMPLETED);
			result.setProductFields(dishWasher);
			return result;
		}
		result.setResultCode(Result.OPERATION_FAILED);
		return result;
	}

	/**
	 * Organizes the operations for adding kitchenRange
	 * 
	 * @param BrandName kitchenRange BrandName
	 * @param modelName kitchenRange modelName
	 * @param price     kitchenRange price
	 * @return the kitchenRange object created
	 */
	public Result addKitchenRange(Request request) {
		Result result = new Result();
		Product kitchenRange = new KitchenRange(request.getBrandName(), request.getModelName(), request.getPrice());
		if (catalog.insertProduct(kitchenRange)) {
			result.setResultCode(Result.OPERATION_COMPLETED);
			result.setProductFields(kitchenRange);
			return result;
		}
		result.setResultCode(Result.OPERATION_FAILED);
		return result;
	}

	/**
	 * Organizes the operations for adding furnace
	 * 
	 * @param BrandName furnace BrandName
	 * @param modelName furnace modelName
	 * @param price     furnace price
	 * @param Btu       furnace Btu
	 * @return the furnace object created
	 */
	public Result addFurnace(Request request) {
		Result result = new Result();
		Product furnace = new Furnace(request.getBrandName(), request.getModelName(), request.getPrice(),
				request.getBtu());
		if (catalog.insertProduct(furnace)) {
			result.setResultCode(Result.OPERATION_COMPLETED);
			result.setProductFields(furnace);
			return result;
		}
		result.setResultCode(Result.OPERATION_FAILED);
		return result;
	}

	/**
	 * Organizes the operations for adding refrigerator
	 * 
	 * @param BrandName refrigerator BrandName
	 * @param modelName refrigerator modelName
	 * @param price     refrigerator price
	 * @param capacity  refrigerator capacity
	 * @return the refrigerator object created
	 */
	public Result addRefrigerator(Request request) {
		Result result = new Result();
		Product refridgerator = new Refrigerator(request.getBrandName(), request.getModelName(), request.getPrice(),
				request.getCapacity());
		if (catalog.insertProduct(refridgerator)) {
			result.setResultCode(Result.OPERATION_COMPLETED);
			result.setProductFields(refridgerator);
			return result;
		}
		result.setResultCode(Result.OPERATION_FAILED);
		return result;
	}

	/**
	 * Organizes the operations for adding a customer
	 * 
	 * @param name    customer name
	 * @param address customer address
	 * @param phone   customer phone
	 * @return the customer object created
	 */
	public Result addCustomer(Request request) {
		Result result = new Result();
		Customer customer = new Customer(request.getCustomerName(), request.getCustomerAddress(),
				request.getCustomerNumber());
		if (customers.insertCustomer(customer)) {
			result.setResultCode(Result.OPERATION_COMPLETED);
			result.setCustomerFields(customer);
			return result;
		}
		result.setResultCode(Result.OPERATION_FAILED);
		return result;
	}

	/**
	 * Searches for a given Customer
	 * 
	 * @param memberId id of the member
	 * @return true iff the member is in the member list collection
	 */
	public Result searchCustomer(Request request) {
		Result result = new Result();
		Customer customer = customers.search(request.getCustomerId());
		if (customer == null) {
			result.setResultCode(Result.NO_SUCH_CUSTOMER);
		} else {
			result.setResultCode(Result.OPERATION_COMPLETED);
			result.setCustomerFields(customer);
		}
		return result;
	}

	/**
	 * Searches for a given product
	 * 
	 * @param productId id of the product
	 * @return true if the product is in the product list collection
	 */
	public Result searchProduct(Request request) {
		Result result = new Result();
		Product product = catalog.search(request.getProductId());
		if (product == null) {
			result.setResultCode(Result.PRODUCT_NOT_FOUND);
		} else {
			result.setResultCode(Result.OPERATION_COMPLETED);
			result.setProductFields(product);
		}
		return result;
	}

	/**
	 * addStock adds a product, based on quantity required to stock
	 * 
	 * @param productId id of the product
	 * @param quantity  to add
	 * @return true if the product can be added to list collection
	 */
	public Result addStock(Request request) {
		Result result = new Result();
		Product product = catalog.search(request.getProductId());
		if (catalog.addToStock(request.getProductId(), request.getStock())) {
			result.setResultCode(Result.OPERATION_COMPLETED);
			result.setProductFields(product);
			return result;
		}
		result.setResultCode(Result.PRODUCT_NOT_FOUND);
		return result;
	}

	/**
	 * purchaseProducts for a given customer searches productId and customerId if
	 * valid it sends to transaction BackOrder accepts the transaction except for
	 * Furnace and returns transaction result
	 * 
	 * @param productId id of the product
	 * @return true if the product is in the product list collection
	 */
	public Result purchaseProducts(Request request) {
		Result result = new Result();
		Product product = catalog.search(request.getProductId()); // check productId
		if (product == null) {
			result.setResultCode(Result.PRODUCT_NOT_FOUND);
			return result;
		}
		result.setProductFields(product);

		Customer customer = customers.search(request.getCustomerId()); // check customer Id
		if (customer == null) {
			result.setResultCode(Result.NO_SUCH_CUSTOMER);
			return result;
		}
		result.setCustomerFields(customer);

		Transaction transaction;
		transaction = (customer.buyProduct(product, customer, request.getPurchaseQuantity())); // add to transaction

		if (transaction == null) {
			result.setResultCode(Result.OPERATION_FAILED);
		} else if (!(transaction.getProductId().substring(0, 1).equals("F"))) { // check for furnace
			result.setTransactionFields(transaction);
			backOrders.add(transaction.getBackOrder()); // backOrder to list
			result.setResultCode(Result.OPERATION_COMPLETED);
		} else if (transaction.getProductId().substring(0, 1).equals("F")) { // if not furnace
			result.setTransactionFields(transaction); // set to transaction fields
			result.setResultCode(Result.OPERATION_COMPLETED);
		}
		return result; // return result
	}

	/**
	 * Searches for a given backOrder
	 * 
	 * @param backOrderId id
	 * @return true if the backOrder is in the backOrder list collection
	 */
	public Result searchBackOrder(Request request) {
		Result result = new Result();
		BackOrder backOrder = backOrders.search(request.getBackOrderId());
		if (backOrder == null) {
			result.setResultCode(Result.PRODUCT_NOT_FOUND);
		} else {
			result.setResultCode(Result.OPERATION_COMPLETED);
			result.setBackOrderFields(backOrder);
		}
		return result;
	}

	/**
	 * fulfillSingleBackOrder for a given backOrder
	 * 
	 * @param backOrderId id
	 * @return true if the backOrder is in the backOrder list collection
	 */
	public Result fulfillSingleBackOrder(Request request) {
		Result result = new Result();
		BackOrder backOrder = backOrders.search(request.getBackOrderId()); // search for backOrderId
		if (backOrder == null) {
			result.setResultCode(Result.PRODUCT_NOT_FOUND);
		}
		if (backOrder.getBackOrderQuantity() < 1) {
			result.setResultCode(Result.PRODUCT_INVALID);
		} else {
			Product product = catalog.search(backOrder.getProductId()); // search productId

			if (backOrder.getBackOrderQuantity() <= product.getStock()) { // if product requested is less than product
																			// in stock
				product.removeStock(backOrder.getBackOrderQuantity()); // fulfill order
				backOrder.setBackOrderQuantity(0); // reset quantity

				result.setResultCode(Result.OPERATION_COMPLETED);
				Customer customer = customers.search(backOrder.getBackOrderCustomerId());
				customer.setTotalBackOrders(customer.getTotalBackOrders() - 1);
				result.setBackOrderFields(backOrder); // setTo backOrder

				result.setProductFields(product); // set backOrder to product
			} else
				result.setResultCode(Result.OPERATION_FAILED); // else fail
		}
		return result; // return result
	}

	/**
	 * enrollInRepairPlan of product for a given customer searches productId, does
	 * not add ClothDryer and ClothWasher
	 * 
	 * @param productId
	 * @param CustomerId
	 * @return true if the RepairPlan is in the RepairPlan list collection
	 */
	public Result enrollInRepairPlan(Request request) {
		Result result = new Result();
		Product product = catalog.search(request.getProductId()); // search productId
		if (product == null) {
			result.setResultCode(Result.PRODUCT_NOT_FOUND);
			return result;
		}
		if (!(product.getProductId().substring(0, 2).equals("CD") // check if not ClothDryer
				|| product.getProductId().substring(0, 2).equals("CW"))) { // check if not ClothWasher
			result.setResultCode(Result.PRODUCT_INVALID);
			return result;
		}
		result.setProductFields(product); // set product fields

		Customer customer = customers.search(request.getCustomerId()); // search customerId
		if (customer == null) {
			result.setResultCode(Result.NO_SUCH_CUSTOMER);
			return result;
		}
		result.setCustomerFields(customer); // set customer fields

		if (product.getProductId().substring(0, 2).equals("CD")
				|| product.getProductId().substring(0, 2).equals("CW")) { // confirm removal again for CD and CW

			if (customer.enrollInRepairPlan(product)) { // add to repairPlan
				result.setResultCode(Result.OPERATION_COMPLETED);
			}
		}
		return result; // return result
	}

	/**
	 * withdrawFromRepairPlan of product for a given customer searches productId,
	 * does not add ClothDryer and ClothWasher
	 * 
	 * @param productId
	 * @param CustomerId
	 * @return true if the RepairPlan is in the RepairPlan list collection
	 */
	public Result withdrawFromRepairPlan(Request request) {
		Result result = new Result();
		Product product = catalog.search(request.getProductId()); // search productId
		if (product == null) {
			result.setResultCode(Result.PRODUCT_NOT_FOUND);
			return result;
		}
		if (!(product.getProductId().substring(0, 2).equals("CD") // check if not ClothDryer
				|| product.getProductId().substring(0, 2).equals("CW"))) { // check if not ClothWasher
			result.setResultCode(Result.PRODUCT_INVALID);
			return result;
		}
		result.setProductFields(product); // set product fields

		Customer customer = customers.search(request.getCustomerId()); // search customerId
		if (customer == null) {
			result.setResultCode(Result.NO_SUCH_CUSTOMER);
			return result;
		}
		result.setCustomerFields(customer); // set customer fields

		if (product.getProductId().substring(0, 2).equals("CD")
				|| product.getProductId().substring(0, 2).equals("CW")) { // confirm removal again for CD and CW

			if (customer.withdrawFromRepairPlan(product)) { // remove from repair list
				result.setResultCode(Result.OPERATION_COMPLETED);
			} else {
				result.setResultCode(Result.OPERATION_FAILED);
			}

		}
		return result; // return result
	}

	/**
	 * chargeAllRepairPlans of product for a given customer
	 * 
	 * customer iterator to return all customers with a repair plan
	 * 
	 * @return true if the RepairPlan is in the RepairPlan list collection
	 */
	public Result chargeAllRepairPlans() {
		Result result = new Result();
		result.setResultCode(Result.OPERATION_FAILED);
		Iterator<Customer> iterator = customers.iterator();
		while (iterator.hasNext()) {
			Customer customer = iterator.next();
			customer.chargeRepairPlan();
			result.setResultCode(Result.OPERATION_COMPLETED);
			result.setCustomerFields(customer);
		}

		return result;
	}

	/**
	 * Returns an iterator to the Result copy for products bought by a customer
	 * 
	 * @param request - stores the customer id
	 * @return iterator to the Result objects storing info about issued books
	 */
	public Iterator<Result> getProducts(Request request) {
		Customer customer = customers.search(request.getCustomerId());
		if (customer == null) {
			return null;
		} else {
			return new SafeProductIterator(customer.getPurchased());
		}
	}

	/**
	 * Returns an iterator to the info. in transactions for a specific customer on a
	 * certain date
	 * 
	 * @param customerId customerId
	 * @param date       date of issue
	 * @return iterator to the collection
	 */
	public Iterator<Result> getTransactions(Request request) {
		Customer customer = customers.search(request.getCustomerId());
		if (customer == null) {
			return new LinkedList<Result>().iterator();
		}
		return customer.getTransactionsOnDate(request.getDate());
	}

	/**
	 * Returns an iterator to the info. All transactions for a specific customer on
	 * a certain date
	 * 
	 * @param customerId customer id
	 * @param date       date of issue
	 * @return iterator to the collection
	 */
	public Iterator<Result> getAllTransactions(Request request) {
		Customer customer = customers.search(request.getCustomerId());
		if (customer == null) {
			return new LinkedList<Result>().iterator();
		}
		return customer.getTransactionsOnDate(request.getDate());
	}

	/**
	 * Retrieves a de-serialized version of the store from disk
	 * 
	 * @return a Library object
	 */
	public static Store retrieve() {
		try {
			FileInputStream file = new FileInputStream("storeData");
			ObjectInputStream input = new ObjectInputStream(file);
			store = (Store) input.readObject();
			Customer.retrieve(input);
			ClothDryer.retrieve(input);
			ClothWasher.retrieve(input);
			DishWasher.retrieve(input);
			Furnace.retrieve(input);
			KitchenRange.retrieve(input);
			Refrigerator.retrieve(input);
			BackOrder.retrieve(input);
			return store;
		} catch (IOException ioe) {
			ioe.printStackTrace();
			return null;
		} catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
			return null;
		}
	}

	/**
	 * Serializes the Library object
	 * 
	 * @return true iff the data could be saved
	 */
	public static boolean save() {
		try {
			FileOutputStream file = new FileOutputStream("StoreData");
			ObjectOutputStream output = new ObjectOutputStream(file);
			output.writeObject(store);
			Customer.save(output);
			ClothDryer.save(output);
			ClothWasher.save(output);
			DishWasher.save(output);
			Furnace.save(output);
			KitchenRange.save(output);
			Refrigerator.save(output);
			BackOrder.save(output);
			file.close();
			return true;
		} catch (IOException ioe) {
			ioe.printStackTrace();
			return false;
		}
	}

	/**
	 * Generates a test bed for the user to test with User Interface
	 */
	public void generateTestBed() {
		AutomatedTester automatedTester = new AutomatedTester();
		automatedTester.testAll();
	}

	/**
	 * Returns an iterator to BackOrder info. The Iterator returned is a safe one,
	 * in the sense that only copies of the BackOrder fields are assembled into the
	 * objects returned via next().
	 * 
	 * @return an Iterator to Result - only the BackOrder fields are valid.
	 */
	public Iterator<Result> getBackOrders() {
		return new SafeBackOrderIterator(backOrders.iterator());
	}

	/**
	 * Returns an iterator to Customer info. The Iterator returned is a safe one, in
	 * the sense that only copies of the Customer fields are assembled into the
	 * objects returned via next().
	 * 
	 * @return an Iterator to Result - only the Customer fields are valid.
	 */
	public Iterator<Result> getCustomers() {
		return new SafeCustomerIterator(customers.iterator());
	}

	/**
	 * Returns an iterator to Product info. The Iterator returned is a safe one, in
	 * the sense that only copies of the Product fields are assembled into the
	 * objects returned via next().
	 * 
	 * @return an Iterator to Result - only the Product fields are valid.
	 */
	public Iterator<Result> getProducts() {
		return new SafeProductIterator(catalog.iterator());
	}

	/**
	 * String form of the Store
	 * 
	 */
	@Override
	public String toString() {
		return catalog + "\n" + customers;
	}

}
