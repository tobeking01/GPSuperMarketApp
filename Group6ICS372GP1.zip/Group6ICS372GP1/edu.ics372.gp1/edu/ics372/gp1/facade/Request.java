package edu.ics372.gp1.facade;

import java.util.GregorianCalendar;

/**
 * This class is used for requesting many of the results of the Store system's
 * business logic to user interface. It is a singleton
 * 
 * At present, the Request object returns an int code,plus values of selected
 * fields of product and Customer. They are the product brandName, modelName,
 * product id, purchasedBy, customer name, customer phone, and customer id.
 * 
 * @author Tobechi Onwenu, Seth Eastwood, Jorel Ngoula
 *
 */

public class Request extends DataTransfer {
	private static Request request;
	private GregorianCalendar date;

	private Request() {

	}

	public static Request instance() {
		if (request == null) {
			request = new Request();
		}
		return request;
	}

	public GregorianCalendar getDate() {
		return date;
	}

	public void setDate(GregorianCalendar date) {
		this.date = date;
	}
}
