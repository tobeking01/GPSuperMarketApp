package edu.ics372.gp1.facade;

/**
 * This class is used for returning many of the results of the store system's
 * business logic to user interface.
 * 
 * At present, the Result object returns an int code,plus values of selected
 * fields of Product and Customer. They are the product brandName, modelName,
 * id, purchaseBy, backOrder, repairPlan, customer name, customer phone, and
 * customer id.
 * 
 * @author Tobechi Onwenu, Seth Eastwood, Jorel Ngoula
 *
 */

public class Result extends DataTransfer {
	public static final int PRODUCT_NOT_FOUND = 1;
	public static final int PRODUCT_NOT_SOLD = 2;
	public static final int PRODUCT_SOLD = 3;
	public static final int OPERATION_COMPLETED = 4;
	public static final int OPERATION_FAILED = 5;
	public static final int NO_SUCH_CUSTOMER = 6;
	public static final int PRODUCT_INVALID = 7;

	private int resultCode;

	public int getResultCode() {
		return resultCode;
	}

	public void setResultCode(int resultCode) {
		this.resultCode = resultCode;
	}

	@Override
	public String toString() {
		return "Result [resultCode=" + resultCode + "]";
	}
}
