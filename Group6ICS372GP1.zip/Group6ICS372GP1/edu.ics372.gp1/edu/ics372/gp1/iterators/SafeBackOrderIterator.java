package edu.ics372.gp1.iterators;

import java.io.Serializable;
import java.util.Iterator;
import java.util.NoSuchElementException;

import edu.ics372.gp1.entities.BackOrder;
import edu.ics372.gp1.facade.Result;

public class SafeBackOrderIterator implements Iterator<Result>, Serializable {
	private static final long serialVersionUID = 1L;
	private Iterator<BackOrder> iterator;
	private Result result = new Result();

	public SafeBackOrderIterator(Iterator<BackOrder> iterator) {
		this.iterator = iterator;
	}

	@Override
	public boolean hasNext() {
		return iterator.hasNext();
	}

	@Override
	public Result next() {
		if (iterator.hasNext()) {
			result.setBackOrderFields(iterator.next());
		} else {
			throw new NoSuchElementException("No such element");
		}
		return result;
	}
}
