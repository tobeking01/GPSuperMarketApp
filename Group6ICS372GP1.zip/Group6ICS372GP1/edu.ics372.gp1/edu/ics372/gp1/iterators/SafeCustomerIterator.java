package edu.ics372.gp1.iterators;

import java.io.Serializable;
import java.util.Iterator;
import java.util.NoSuchElementException;

import edu.ics372.gp1.entities.Customer;
import edu.ics372.gp1.facade.Result;

/**
 * This Iterator implementation is tailor-made to supply a "read-only" version
 * of Customer objects. The user should supply an iterator to Customer as the
 * parameter to the constructor.
 * 
 * @author Tobechi Onwenu, Seth Eastwood, Jorel Ngoula
 *
 */
public class SafeCustomerIterator implements Iterator<Result>, Serializable {
	private static final long serialVersionUID = 1L;
	private Iterator<Customer> iterator;
	private Result result = new Result();

	/**
	 * The user of SafeIterator must supply an Iterator to Book.
	 * 
	 * @param iterator Iterator<Book>
	 */
	public SafeCustomerIterator(Iterator<Customer> iterator) {
		this.iterator = iterator;
	}

	@Override
	public boolean hasNext() {
		return iterator.hasNext();
	}

	@Override
	public Result next() {
		if (iterator.hasNext()) {
			result.setCustomerFields(iterator.next());
		} else {
			throw new NoSuchElementException("No such element");
		}
		return result;
	}

}
