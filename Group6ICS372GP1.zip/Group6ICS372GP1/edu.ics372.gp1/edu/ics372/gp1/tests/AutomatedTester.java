package edu.ics372.gp1.tests;

import edu.ics372.gp1.entities.BackOrder;
import edu.ics372.gp1.entities.Customer;
import edu.ics372.gp1.entities.Product;
import edu.ics372.gp1.entities.Transaction;
import edu.ics372.gp1.facade.Request;
import edu.ics372.gp1.facade.Result;
import edu.ics372.gp1.facade.Store;

public class AutomatedTester {
	private Store store;
	private String[] names = { "Seth", "Alex", "Ashley", "Will", "Wallace", "Nick", "Jeremy" };
	private String[] addresses = { "123 Bee St.", "456 Elm St.", "789 Lee St.", "342 Bee St.", "6432 Elm St.",
			"253 Lee St.", "423 Bee St." };
	private String[] number = { "644-343-2553", "342-532-3433", "364-444-6454", "644-343-2553", "342-532-3433",
			"364-444-6454", "364-444-6454" };
	private Customer[] customers = new Customer[7];
	private String[] brandNames = { "bn1", "bn2", "bn3", "bn4", "bn5" };
	private String[] modelNames = { "mn1", "mn2", "mna3", "mn4", "mn5" };
	private double[] price = { 500.00, 324.99, 600.50, 240.99, 510.50 };
	private double[] monthlyRepairPlanCosts = { 50.00, 34.99, 60.50, 24.99, 51.50 };
	private int stocks = 4;
	private int[] btus = { 2, 4, 56, 7, 8 };
	private int[] capacities = { 5, 3, 6, 2, 5 };
	private Product[] products = new Product[5];
	private Transaction[] transactions = new Transaction[3];
	private BackOrder[] backOrders = new BackOrder[5];

	/**
	 * Tests Customer creation.
	 */
	public void testAddCustomer() {
		for (int count = 0; count < customers.length; count++) {
			Request.instance().setCustomerName(names[count]);
			Request.instance().setCustomerAddress(addresses[count]);
			Request.instance().setCustomerNumber(number[count]);
			Result result = Store.instance().addCustomer(Request.instance());
			assert result.getResultCode() == Result.OPERATION_COMPLETED;
			assert result.getResultCode() != Result.OPERATION_FAILED;
			assert result.getCustomerName().equals(names[count]);
			assert result.getCustomerAddress().equals(addresses[count]);
			assert result.getCustomerNumber().equals(number[count]);
//			assert result.getCustomerId() != null;
		}
	}

	public void testAddClothDryer() {
		for (int count = 0; count < products.length; count++) {
			Request.instance().setBrandName(brandNames[count]);
			Request.instance().setModelName(modelNames[count]);
			Request.instance().setPrice(price[count]);
			Request.instance().setMonthlyRepairPlanCost(monthlyRepairPlanCosts[count]);
			Result result = Store.instance().addClothDryer(Request.instance());
			assert result.getResultCode() == Result.OPERATION_COMPLETED;
			assert result.getResultCode() != Result.OPERATION_FAILED;
			assert result.getBrandName().equals(brandNames[count]);
			assert result.getModelName().equals(modelNames[count]);
			assert result.getPrice() == (price[count]);
			assert result.getMonthlyRepairPlanCost() == (monthlyRepairPlanCosts[count]);

		}
	}

	public void testAddClothWasher() {
		for (int count = 0; count < products.length; count++) {
			Request.instance().setBrandName(brandNames[count]);
			Request.instance().setModelName(modelNames[count]);
			Request.instance().setPrice(price[count]);
			Request.instance().setMonthlyRepairPlanCost(monthlyRepairPlanCosts[count]);
			Result result = Store.instance().addClothWasher(Request.instance());
			assert result.getResultCode() == Result.OPERATION_COMPLETED;
			assert result.getResultCode() != Result.OPERATION_FAILED;
			assert result.getBrandName().equals(brandNames[count]);
			assert result.getModelName().equals(modelNames[count]);
			assert result.getPrice() == (price[count]);
			assert result.getMonthlyRepairPlanCost() == (monthlyRepairPlanCosts[count]);

		}
	}

	public void testAddDishWasher() {
		for (int count = 0; count < products.length; count++) {
			Request.instance().setBrandName(brandNames[count]);
			Request.instance().setModelName(modelNames[count]);
			Request.instance().setPrice(price[count]);
			Result result = Store.instance().addDishWasher(Request.instance());
			assert result.getResultCode() == Result.OPERATION_COMPLETED;
			assert result.getResultCode() != Result.OPERATION_FAILED;
			assert result.getBrandName().equals(brandNames[count]);
			assert result.getModelName().equals(modelNames[count]);
			assert result.getPrice() == (price[count]);
		}
	}

	public void testAddKitchenRange() {
		for (int count = 0; count < products.length; count++) {
			Request.instance().setBrandName(brandNames[count]);
			Request.instance().setModelName(modelNames[count]);
			Request.instance().setPrice(price[count]);
			Result result = Store.instance().addKitchenRange(Request.instance());
			assert result.getResultCode() == Result.OPERATION_COMPLETED;
			assert result.getResultCode() != Result.OPERATION_FAILED;
			assert result.getBrandName().equals(brandNames[count]);
			assert result.getModelName().equals(modelNames[count]);
			assert result.getPrice() == (price[count]);
		}
	}

	public void testAddFurnace() {
		for (int count = 0; count < products.length; count++) {
			Request.instance().setBrandName(brandNames[count]);
			Request.instance().setModelName(modelNames[count]);
			Request.instance().setPrice(price[count]);
			Request.instance().setBtu(btus[count]);
			Result result = Store.instance().addFurnace(Request.instance());
			assert result.getResultCode() == Result.OPERATION_COMPLETED;
			assert result.getResultCode() != Result.OPERATION_FAILED;
			assert result.getBrandName().equals(brandNames[count]);
			assert result.getModelName().equals(modelNames[count]);
			assert result.getPrice() == (price[count]);
			assert result.getBtu() == (btus[count]);
		}
	}

	public void testAddRefrigerator() {
		for (int count = 0; count < products.length; count++) {
			Request.instance().setBrandName(brandNames[count]);
			Request.instance().setModelName(modelNames[count]);
			Request.instance().setPrice(price[count]);
			Request.instance().setCapacity(capacities[count]);
			Result result = Store.instance().addRefrigerator(Request.instance());
			assert result.getResultCode() == Result.OPERATION_COMPLETED;
			assert result.getResultCode() != Result.OPERATION_FAILED;
			assert result.getBrandName().equals(brandNames[count]);
			assert result.getModelName().equals(modelNames[count]);
			assert result.getPrice() == (price[count]);
			assert result.getCapacity() == (capacities[count]);
		}
	}

	public void testSearchCustomer() {
		Request.instance().setCustomerId("C1");
		assert Store.instance().searchCustomer(Request.instance()).getCustomerId().equals("C1");
		Request.instance().setCustomerId("C2");
		assert Store.instance().searchCustomer(Request.instance()).getCustomerId().equals("C2");
		Request.instance().setCustomerId("C3");
		assert Store.instance().searchCustomer(Request.instance()) != null;

	}

	public void testSearchProduct() {
		Request.instance().setProductId("CD1");
		assert Store.instance().searchProduct(Request.instance()).getProductId().equals("CD1");
		Request.instance().setProductId("CW2");
		assert Store.instance().searchProduct(Request.instance()).getProductId().equals("CW2");
		Request.instance().setProductId("F5");
		assert Store.instance().searchProduct(Request.instance()).getProductId().equals("F5");
		Request.instance().setProductId("F6");
		assert Store.instance().searchProduct(Request.instance()) != null;
	}

	private void testAddStock() {
		Request.instance().setProductId("CD1");
		Request.instance().setStock(stocks);
		Result result = Store.instance().addStock(Request.instance());
		Request.instance().setProductId("CW1");
		Request.instance().setStock(stocks);
		result = Store.instance().addStock(Request.instance());
		Request.instance().setProductId("DW1");
		Request.instance().setStock(stocks);
		result = Store.instance().addStock(Request.instance());
		Request.instance().setProductId("F1");
		Request.instance().setStock(stocks);
		result = Store.instance().addStock(Request.instance());
		Request.instance().setProductId("KR1");
		Request.instance().setStock(stocks);
		result = Store.instance().addStock(Request.instance());
		Request.instance().setProductId("R1");
		Request.instance().setStock(stocks);
		result = Store.instance().addStock(Request.instance());
		assert result.getResultCode() == Result.OPERATION_COMPLETED;
		assert result.getResultCode() != Result.PRODUCT_NOT_FOUND;
	}

	private void testPurchaseProducts() {
		Request.instance().setCustomerId("C1");
		Request.instance().setProductId("CD1");
		Request.instance().setPurchaseQuantity(10);
		Result result = Store.instance().purchaseProducts(Request.instance());
		Request.instance().setCustomerId("C2");
		Request.instance().setProductId("CW1");
		Request.instance().setPurchaseQuantity(20);
		result = Store.instance().purchaseProducts(Request.instance());
		Request.instance().setCustomerId("C3");
		Request.instance().setProductId("DW1");
		Request.instance().setPurchaseQuantity(15);
		result = Store.instance().purchaseProducts(Request.instance());
		Request.instance().setCustomerId("C4");
		Request.instance().setProductId("KR3");
		Request.instance().setPurchaseQuantity(17);
		result = Store.instance().purchaseProducts(Request.instance());
		Request.instance().setCustomerId("C5");
		Request.instance().setProductId("R2");
		Request.instance().setPurchaseQuantity(20);
		result = Store.instance().purchaseProducts(Request.instance());
		Request.instance().setCustomerId("C6");
		Request.instance().setProductId("F1");
		Request.instance().setPurchaseQuantity(21);
		result = Store.instance().purchaseProducts(Request.instance());
		Request.instance().setCustomerId("C7");
		Request.instance().setProductId("F1");
		Request.instance().setPurchaseQuantity(10);
		result = Store.instance().purchaseProducts(Request.instance());
//		transaction = (customers[1].buyProduct(products[1], customers[1], stocks));

		assert result.getResultCode() == Result.OPERATION_FAILED;
		assert result.getResultCode() != Result.OPERATION_COMPLETED;
		assert result.getResultCode() != Result.PRODUCT_NOT_FOUND;
		assert result.getResultCode() != Result.NO_SUCH_CUSTOMER;
		assert result.getResultCode() == Result.OPERATION_FAILED;
	}

	private void testSearchBackOrder() {
		Request.instance().setBackOrderId("BO1");
		assert Store.instance().searchBackOrder(Request.instance()).getBackOrderId().equals("BO1");
	}

	private void testFulFillBackorders() {
		Request.instance().setBackOrderId("BO1");
		Result result = Store.instance().fulfillSingleBackOrder(Request.instance());
		Request.instance().setBackOrderId("BO2");
		result = Store.instance().fulfillSingleBackOrder(Request.instance());
		Request.instance().setBackOrderId("BO3");
		result = Store.instance().fulfillSingleBackOrder(Request.instance());
		Request.instance().setBackOrderId("BO4");
		result = Store.instance().fulfillSingleBackOrder(Request.instance());
		Request.instance().setBackOrderId("BO5");
		result = Store.instance().fulfillSingleBackOrder(Request.instance());

		assert result.getResultCode() == Result.OPERATION_FAILED;
		assert result.getResultCode() != Result.OPERATION_COMPLETED;
		assert result.getResultCode() != Result.PRODUCT_NOT_FOUND;
		assert result.getResultCode() != Result.NO_SUCH_CUSTOMER;
		assert result.getResultCode() == Result.OPERATION_FAILED;
	}

	private void testEnrollInRepairPlan() {
		Request.instance().setCustomerId("C1");
		Request.instance().setProductId("CD1");
		Result result = Store.instance().enrollInRepairPlan(Request.instance());
		Request.instance().setCustomerId("C1");
		Request.instance().setProductId("CW3");
		result = Store.instance().enrollInRepairPlan(Request.instance());
		Request.instance().setCustomerId("C2");
		Request.instance().setProductId("CW1");
		result = Store.instance().enrollInRepairPlan(Request.instance());
		Request.instance().setCustomerId("C3");
		Request.instance().setProductId("DW1");
		result = Store.instance().enrollInRepairPlan(Request.instance());
		Request.instance().setCustomerId("C4");
		Request.instance().setProductId("F1");
		result = Store.instance().enrollInRepairPlan(Request.instance());
		Request.instance().setCustomerId("C5");
		Request.instance().setProductId("R1");
		result = Store.instance().enrollInRepairPlan(Request.instance());
		assert result.getResultCode() != Result.OPERATION_FAILED;
		assert result.getResultCode() != Result.OPERATION_COMPLETED;
		assert result.getResultCode() != Result.PRODUCT_NOT_FOUND;
		assert result.getResultCode() != Result.NO_SUCH_CUSTOMER;
		assert result.getResultCode() != Result.OPERATION_FAILED;
	}

	private void testWithdrawFromRepairPlan() {
		Request.instance().setCustomerId("C1");
		Request.instance().setProductId("CD1");
		Result result = Store.instance().withdrawFromRepairPlan(Request.instance());
		Request.instance().setCustomerId("C2");
		Request.instance().setProductId("CW1");
		result = Store.instance().withdrawFromRepairPlan(Request.instance());
		Request.instance().setCustomerId("C3");
		Request.instance().setProductId("DW1");
		result = Store.instance().withdrawFromRepairPlan(Request.instance());
		Request.instance().setCustomerId("C4");
		Request.instance().setProductId("F1");
		result = Store.instance().withdrawFromRepairPlan(Request.instance());
		Request.instance().setCustomerId("C5");
		Request.instance().setProductId("R1");
		result = Store.instance().withdrawFromRepairPlan(Request.instance());
		assert result.getResultCode() != Result.OPERATION_FAILED;
		assert result.getResultCode() != Result.OPERATION_COMPLETED;
		assert result.getResultCode() != Result.PRODUCT_NOT_FOUND;
		assert result.getResultCode() != Result.NO_SUCH_CUSTOMER;
		assert result.getResultCode() != Result.OPERATION_FAILED;
	}

	private void testChargeAllRepairPlans() {
		Store.instance().chargeAllRepairPlans();
	}

	public void testAll() {
		testAddCustomer();
		testAddClothDryer();
		testAddClothWasher();
		testAddDishWasher();
		testAddKitchenRange();
		testAddFurnace();
		testAddRefrigerator();
		testSearchCustomer();
		testSearchProduct();
		testAddStock();
		testPurchaseProducts();
		testSearchBackOrder();
		testFulFillBackorders();
		testEnrollInRepairPlan();
		testChargeAllRepairPlans();
		testWithdrawFromRepairPlan();
		testAddStock();
		testAddStock();
		testFulFillBackorders();
		testWithdrawFromRepairPlan();
	}

	public static void main(String[] args) {
		new AutomatedTester().testAll();
	}
}
