package edu.ics372.gp1.collections;

import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import edu.ics372.gp1.entities.Customer;

/** @author Group 6: Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
* @Copyright (c) 2022
* 
*            Redistribution and use with or without modification, are permitted
*            provided that the following conditions are met:
*
*            - the use is for academic purpose only - Redistributions of source
*            code must retain the above copyright notice, this list of
*            conditions and the following disclaimer. - Neither the name of
*            Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy. may be used to endorse or promote
*            products derived from this software without specific prior written
*            permission.
*
*            The authors do not make any claims regarding the correctness of
*            the code in this module and are not responsible for any loss or
*            damage resulting from its use.
*/

/**
 * CustomerList keeps a collection of all customers in the store
 * 
 * @author Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
 *
 */

public class CustomerList implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<Customer> customers = new LinkedList<>();
	private static CustomerList customerList;

	/**
	 * Singleton Catalog
	 */
	private CustomerList() {

	}

	public static CustomerList getInstance() {
		if (customerList == null) {
			customerList = new CustomerList();
		}
		return customerList;
	}

	/**
	 * search Customer to based on customerId
	 * 
	 * @param customerId
	 * @return
	 */
	public Customer search(String customerId) {
		for (Iterator<Customer> iterator = customers.iterator(); iterator.hasNext();) {
			Customer customer = iterator.next();
			if (customer.getId().equals(customerId)) {
				return customer;
			}
		}
		return null;
	}

	/**
	 * insertCustomer method adds a customer
	 * 
	 * @param customer
	 * @return
	 */
	public boolean insertCustomer(Customer customer) {
		customers.add(customer);
		return true;
	}

	/**
	 * Customer iterator
	 * 
	 * @return
	 */
	public Iterator<Customer> iterator() {
		return customers.iterator();
	}

	@Override
	public String toString() {
		return customers.toString();
	}

}
