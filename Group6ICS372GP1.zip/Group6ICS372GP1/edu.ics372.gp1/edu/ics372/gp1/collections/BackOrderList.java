package edu.ics372.gp1.collections;

import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import edu.ics372.gp1.entities.BackOrder;

/** @author Group 6: Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
* @Copyright (c) 2022
* 
*            Redistribution and use with or without modification, are permitted
*            provided that the following conditions are met:
*
*            - the use is for academic purpose only - Redistributions of source
*            code must retain the above copyright notice, this list of
*            conditions and the following disclaimer. - Neither the name of
*            Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy. may be used to endorse or promote
*            products derived from this software without specific prior written
*            permission.
*
*            The authors do not make any claims regarding the correctness of
*            the code in this module and are not responsible for any loss or
*            damage resulting from its use.
*/

/**
 * BackOrderList keeps a collection of all backOrders of customers in the store
 * 
 * @author Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
 *
 */

public class BackOrderList implements Iterable<BackOrder>, Serializable {

	private static final long serialVersionUID = 1L;
	private List<BackOrder> backOrders = new LinkedList<>();
	private static BackOrderList backOrderList;

	/**
	 * Singleton Catalog
	 */
	private BackOrderList() {
	}

	public static BackOrderList getInstance() {
		if (backOrderList == null) {
			backOrderList = new BackOrderList();
		}
		return backOrderList;
	}

	/**
	 * addbackOrder
	 * 
	 * @param backOrder
	 */
	public void add(BackOrder backOrder) {
		backOrders.add(backOrder);

	}

	/**
	 * search backOrder based on backorderId (customerId)
	 * 
	 * @param backOrderId
	 * @return
	 */
	public BackOrder search(String backOrderId) {
		for (Iterator<BackOrder> iterator = backOrders.iterator(); iterator.hasNext();) {
			BackOrder backOrder = iterator.next();
			if (backOrder.getBackOrderId().equals(backOrderId)) {
				return backOrder;
			}
		}
		return null;
	}

	/**
	 * insertBackOrder into backOrderList
	 * 
	 * @param backOrder
	 * @return
	 */
	public boolean insertBackOrder(BackOrder backOrder) {
		backOrders.add(backOrder);
		return true;
	}

	/**
	 * BackOrder iterator
	 */
	public Iterator<BackOrder> iterator() {
		return backOrders.iterator();
	}

	@Override
	public String toString() {
		return backOrders.toString();
	}

}
