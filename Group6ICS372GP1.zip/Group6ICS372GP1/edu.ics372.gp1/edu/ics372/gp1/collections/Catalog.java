package edu.ics372.gp1.collections;

import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import edu.ics372.gp1.entities.Product;

/** @author Group 6: Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
* @Copyright (c) 2022
* 
*            Redistribution and use with or without modification, are permitted
*            provided that the following conditions are met:
*
*            - the use is for academic purpose only - Redistributions of source
*            code must retain the above copyright notice, this list of
*            conditions and the following disclaimer. - Neither the name of
*            Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy. may be used to endorse or promote
*            products derived from this software without specific prior written
*            permission.
*
*            The authors do not make any claims regarding the correctness of
*            the code in this module and are not responsible for any loss or
*            damage resulting from its use.
*/

/**
 * Catalog keeps track of the collection of products iterable product items
 * 
 * @author Eastwood Seth, Tobechi Onwenu, Ngoula Jorel and Chau Jeremy.
 *
 */

public class Catalog implements Iterable<Product>, Serializable {

	private static final long serialVersionUID = 1L;
	private static Catalog catalog;
	private List<Product> products = new LinkedList<Product>();

	/**
	 * Singleton Catalog
	 */
	private Catalog() {

	}

	public static Catalog getInstance() {
		if (catalog == null) {
			catalog = new Catalog();
		}
		return catalog;
	}

	/**
	 * search method searches based on productId
	 * 
	 * @param productId
	 * @return
	 */
	public Product search(String productId) {
		for (Iterator<Product> iterator = products.iterator(); iterator.hasNext();) {// iterate over product
			Product product = iterator.next(); // while iterator has next
			if (product.getProductId().equals(productId)) { // check based on equals method
				return product; // return product
			}
		}
		return null; // return null
	}

	/**
	 * insertProduct adds a product
	 * 
	 * @param product
	 * @return
	 */
	public boolean insertProduct(Product product) {
		this.products.add(product);
		return true;
	}

	/**
	 * addToStock adds to stock product with quantity specified
	 * 
	 * @param productId
	 * @param quantity
	 * @return
	 */
	public boolean addToStock(String productId, int quantity) {
		try {
			search(productId).addStock(quantity);
			return true;
		} catch (Exception fe) {
			return false;
		}
	}

	/**
	 * product iterator in catalog
	 */
	@Override
	public Iterator<Product> iterator() {
		return products.iterator();
	}

	/**
	 * String form of the collection
	 * 
	 */
	public String toString() {
		return products.toString();
	}
}
