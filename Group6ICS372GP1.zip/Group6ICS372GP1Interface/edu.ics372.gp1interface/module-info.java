module edu.ics372.gp1interface {
	requires edu.ics372.gp1;
}