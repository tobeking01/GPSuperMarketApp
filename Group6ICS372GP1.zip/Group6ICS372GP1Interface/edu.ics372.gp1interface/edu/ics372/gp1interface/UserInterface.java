package edu.ics372.gp1interface;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.StringTokenizer;

import edu.ics372.gp1.facade.Request;
import edu.ics372.gp1.facade.Result;
import edu.ics372.gp1.facade.Store;

/**
 * This is the User Interface for interacting with the Store
 * 
 * @authors Seth Eastwood, Tobechi Onwenu, Jorel Ngoula
 *
 */

public class UserInterface {

	private static UserInterface userInterface;
	private BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
	private static Store store;
	private static final int EXIT = 0;
	private static final int ADD_MODEL = 1;
	private static final int ADD_CUSTOMER = 2;
	private static final int ADD_TO_INVENTORY = 3;
	private static final int PURCHASE_PRODUCT = 4;
	private static final int GET_CUSTOMERS = 5;
	private static final int GET_PRODUCTS = 6;
	private static final int GET_BACKORDERS = 7;
	private static final int FULFILL_SINGLE_BACKORDER = 8;
	private static final int EDIT_OR_PRINT_REPAIR_PLANS = 9;
	private static final int PRINT_REVENUE = 10;
	private static final int SAVE = 11;
	private static final int HELP = 15;

	private static final int ENROLL_IN_REPAIR_PLAN = 1;
	private static final int WITHDRAW_FROM_REPAIR_PLAN = 2;
	private static final int GET_ALL_REPAIR_PLANS = 3;
	private static final int CHARGE_ALL_REPAIR_PLANS = 4;

	private static final int ADD_CLOTH_DRYER = 1;
	private static final int ADD_CLOTH_WASHER = 2;
	private static final int ADD_DISH_WASHER = 3;
	private static final int ADD_FURNACE = 4;
	private static final int ADD_KITCHEN_RANGE = 5;
	private static final int ADD_REFRIGERATOR = 6;

	private static final int GET_ALL_APPLIANCES = 1;
	private static final int GET_ALL_CLOTH_DRYERS = 2;
	private static final int GET_ALL_CLOTH_WASHERS = 3;
	private static final int GET_ALL_DISH_WASHERS = 4;
	private static final int GET_ALL_FURNACES = 5;
	private static final int GET_ALL_KITCHEN_RANGES = 6;
	private static final int GET_ALL_REFRIGERATORS = 7;

	/**
	 * Made private for singleton pattern. Conditionally looks for any saved data.
	 * Otherwise, it asks if the user wants to generate a test bed, else it gets a
	 * singleton store object.
	 */
	private UserInterface() {
		if (yesOrNo("Look for saved data and  use it?")) {
			retrieve();
		} else if (yesOrNo("Generate a test bed?")) {
			generateTestBed();
		} else {
			store = store.instance();
		}
	}

	/**
	 * Generates a test bed
	 */
	private void generateTestBed() {
		store = store.instance();
		store.generateTestBed();
	}

	/**
	 * Supports the singleton pattern
	 * 
	 * @return the singleton object
	 */
	public static UserInterface instance() {
		if (userInterface == null) {
			return userInterface = new UserInterface();
		} else {
			return userInterface;
		}
	}

	/**
	 * Gets a token after prompting
	 * 
	 * @param prompt - whatever the user wants as prompt
	 * @return - the token from the keyboard
	 * 
	 */
	public String getToken(String prompt) {
		do {
			try {
				System.out.println(prompt);
				String line = reader.readLine();
				StringTokenizer tokenizer = new StringTokenizer(line, "\n\r\f");
				if (tokenizer.hasMoreTokens()) {
					return tokenizer.nextToken();
				}
			} catch (IOException ioe) {
				System.exit(0);
			}
		} while (true);
	}

	/**
	 * Gets a name after prompting
	 * 
	 * @param prompt - whatever the user wants as prompt
	 * @return - the token from the keyboard
	 * 
	 */
	public String getName(String prompt) {
		do {
			try {
				System.out.println(prompt);
				String line = reader.readLine();
				return line;
			} catch (IOException ioe) {
				System.exit(0);
			}
		} while (true);

	}

	/**
	 * Queries for a yes or no and returns true for yes and false for no
	 * 
	 * @param prompt The string to be prepended to the yes/no prompt
	 * @return true for yes and false for no
	 * 
	 */
	private boolean yesOrNo(String prompt) {
		String more = getToken(prompt + " (Y|y)[es] or anything else for no");
		if (more.charAt(0) != 'y' && more.charAt(0) != 'Y') {
			return false;
		}
		return true;
	}

	/**
	 * Converts the string to a number
	 * 
	 * @param prompt the string for prompting
	 * @return the integer corresponding to the string
	 * 
	 */
	public int getNumber(String prompt) {
		do {
			try {
				String item = getToken(prompt);
				Integer number = Integer.valueOf(item);
				return number.intValue();
			} catch (NumberFormatException nfe) {
				System.out.println("Please input a number ");
			}
		} while (true);
	}

	/**
	 * Converts the string to a double
	 * 
	 * @param prompt the string for prompting
	 * @return the double corresponding to the string
	 * 
	 */
	public double getNumberDouble(String prompt) {
		do {
			try {
				String item = getToken(prompt);
				double number = Double.valueOf(item);
				return number;
			} catch (NumberFormatException nfe) {
				System.out.println("Please input a number ");
			}
		} while (true);
	}

	/**
	 * Prompts for a date and gets a date object
	 * 
	 * @param prompt the prompt
	 * @return the data as a Calendar object
	 */
	public GregorianCalendar getDate(String prompt) {
		do {
			try {
				GregorianCalendar date = new GregorianCalendar();
				String item = getToken(prompt);
				DateFormat dateFormat = SimpleDateFormat.getDateInstance(DateFormat.SHORT);
				date.setTime(dateFormat.parse(item));
				return date;
			} catch (Exception fe) {
				System.out.println("Please input a date as mm/dd/yy");
			}
		} while (true);
	}

	/**
	 * Prompts for a command from the keyboard
	 * 
	 * @return a valid command
	 * 
	 */
	public int getCommand() {
		do {
			try {
				int value = Integer.parseInt(getToken("Enter command:" + HELP + " for help"));
				if (value >= EXIT && value <= HELP) {
					return value;
				}
			} catch (NumberFormatException nfe) {
				System.out.println("Enter a number");
			}
		} while (true);
	}

	/**
	 * Prompts for a command from the keyboard
	 * 
	 * @return a valid command
	 * 
	 */
	public int getAppliance() {
		do {
			try {
				int value = Integer.parseInt(getToken("Enter Appliance type:" + HELP + " for help"));
				if (value >= EXIT && value <= HELP) {
					return value;
				}
			} catch (NumberFormatException nfe) {
				System.out.println("Enter a number");
			}
		} while (true);
	}

	/**
	 * Displays the main help screen
	 * 
	 */
	public void help1() {
		System.out.println("Enter a number between 0 and 15 as explained below:");
		System.out.println(EXIT + " to Exit");
		System.out.println(ADD_MODEL + " to add a single model");
		System.out.println(ADD_CUSTOMER + " to add a CUSTOMER");
		System.out.println(ADD_TO_INVENTORY + " to add products to INVENTORY");
		System.out.println(PURCHASE_PRODUCT + " to PURCHASE products by a customer");
		System.out.println(GET_CUSTOMERS + " to print ALL customers");
		System.out.println(GET_PRODUCTS + " to access PRINT PRODUCTS menu");
		System.out.println(GET_BACKORDERS + " to print ALL BACK ORDERS");
		System.out.println(FULFILL_SINGLE_BACKORDER + " to fulfill a single BACK ORDER");
		System.out.println(EDIT_OR_PRINT_REPAIR_PLANS + " to access REPAIR PLANS menu");
		System.out.println(PRINT_REVENUE + " to print revenue from sales and repair plans");
		System.out.println(SAVE + " to SAVE data");
		System.out.println(HELP + " for HELP");
	}

	/**
	 * Displays the add model selection screen
	 * 
	 */
	public void help2() {
		System.out.println("Enter a number between 0 and 6 as explained below:");
		System.out.println(EXIT + " to Exit");
		System.out.println(ADD_CLOTH_DRYER + " to add a cloth dryer");
		System.out.println(ADD_CLOTH_WASHER + " to add a cloth washer");
		System.out.println(ADD_DISH_WASHER + " to add a dish washer");
		System.out.println(ADD_FURNACE + " to add a furnace");
		System.out.println(ADD_KITCHEN_RANGE + " to add a kitchen range");
		System.out.println(ADD_REFRIGERATOR + " to add a refrigerator");
		System.out.println(HELP + " for help");
	}

	/**
	 * displays the print out appliance menu
	 */
	public void help3() {
		System.out.println("Enter a number between 0 and 7 as explained below:");
		System.out.println(EXIT + " to Exit");
		System.out.println(GET_ALL_APPLIANCES + " to print all appliances");
		System.out.println(GET_ALL_CLOTH_DRYERS + " to print all cloth dryers");
		System.out.println(GET_ALL_CLOTH_WASHERS + " to print all cloth washers");
		System.out.println(GET_ALL_DISH_WASHERS + " to print all dish washers");
		System.out.println(GET_ALL_FURNACES + " to print all furnaces");
		System.out.println(GET_ALL_KITCHEN_RANGES + " to print all kitchen ranges");
		System.out.println(GET_ALL_REFRIGERATORS + " to print all refrigerators");
		System.out.println(HELP + " for help");
	}

	/**
	 * displays the repair plan menu
	 */
	public void help4() {
		System.out.println("Enter a number between 0 and 4 as explained below:");
		System.out.println(EXIT + " to Exit");
		System.out.println(ENROLL_IN_REPAIR_PLAN + " to enroll a customer in a repair plan");
		System.out.println(WITHDRAW_FROM_REPAIR_PLAN + " to withdraw a customer from a repair plan");
		System.out.println(GET_ALL_REPAIR_PLANS + " to get all customers with repair plans");
		System.out.println(CHARGE_ALL_REPAIR_PLANS + " to charge all repair plans");
		System.out.println(HELP + " for help");
	}

	/**
	 * Orchestrates the whole process. Calls the appropriate method for the
	 * different functionalities.
	 * 
	 */
	public void processMainMenu() {
		int command;
		help1();
		while ((command = getCommand()) != EXIT) {
			switch (command) {
			case ADD_MODEL:
				addModel();
				break;
			case ADD_CUSTOMER:
				addCustomer();
				break;
			case ADD_TO_INVENTORY:
				addInventory();
				break;
			case PURCHASE_PRODUCT:
				purchaseProducts();
				break;
			case GET_CUSTOMERS:
				getCustomers();
				break;
			case GET_PRODUCTS:
				processGetAppliances();
				break;
			case GET_BACKORDERS:
				getBackOrders();
				break;
			case FULFILL_SINGLE_BACKORDER:
				fulfillSingleBackOrder();
				break;
			case EDIT_OR_PRINT_REPAIR_PLANS:
				editOrPrintRepairPlans();
				break;
			case PRINT_REVENUE:
				printRevenue();
				break;
			case SAVE:
				save();
				break;
			case HELP:
				help1();
				break;
			}
		}
	}

	/**
	 * orchestrates the process of selecting which appliances to print
	 */
	public void processGetAppliances() {
		int command;
		help3();
		while ((command = getCommand()) != EXIT) {
			switch (command) {
			case GET_ALL_APPLIANCES:
				getAllProducts();
				break;
			case GET_ALL_CLOTH_DRYERS:
				getAllOfSelectedAppliance(GET_ALL_CLOTH_DRYERS);
				break;
			case GET_ALL_CLOTH_WASHERS:
				getAllOfSelectedAppliance(GET_ALL_CLOTH_WASHERS);
				break;
			case GET_ALL_DISH_WASHERS:
				getAllOfSelectedAppliance(GET_ALL_DISH_WASHERS);
				break;
			case GET_ALL_FURNACES:
				getAllOfSelectedAppliance(GET_ALL_FURNACES);
				break;
			case GET_ALL_KITCHEN_RANGES:
				getAllOfSelectedAppliance(GET_ALL_KITCHEN_RANGES);
				break;
			case GET_ALL_REFRIGERATORS:
				getAllOfSelectedAppliance(GET_ALL_REFRIGERATORS);
				break;
			case HELP:
				help3();
				break;
			}
		}
	}

	/**
	 * orchestrates the process of selecting which product to add
	 */
	public void addModel() {
		int command;
		help2();
		command = getAppliance();
		{
			switch (command) {
			case ADD_CLOTH_DRYER:
				addClothDryer();
//				help1();
				break;
			case ADD_CLOTH_WASHER:
				addClothWasher();
//				help1();
				break;
			case ADD_DISH_WASHER:
				addDishWasher();
//				help1();
				break;
			case ADD_FURNACE:
				addFurnace();
//				help1();
				break;
			case ADD_KITCHEN_RANGE:
				addKitchenRange();
//				help1();
				break;
			case ADD_REFRIGERATOR:
				addRefrigerator();
//				help1();
				break;
			case HELP:
				help2();
				break;
			}
		}
	}

	/**
	 * orchestrates the process of editing or viewing repair plans
	 */
	public void editOrPrintRepairPlans() {
		int command;
		help4();
		while ((command = getAppliance()) != EXIT) {
			switch (command) {
			case ENROLL_IN_REPAIR_PLAN:
				enrollInRepairPlan();
				break;
			case WITHDRAW_FROM_REPAIR_PLAN:
				withdrawFromRepairPlan();
				break;
			case GET_ALL_REPAIR_PLANS:
				getCustomersRepairPlans();
				break;
			case CHARGE_ALL_REPAIR_PLANS:
				chargeAllRepairPlans();
				break;

			case HELP:
				help4();
				break;

			}
		}
	}

//	This is the new UserInterface corresponding code to add product types:

	/**
	 * Method to be called for adding a cloth dryer prompts the user for appropriate
	 * values and uses the appropriate store method for adding the cloth dryer
	 */
	public void addClothDryer() {
		System.out.println("Adding Cloth Dryer:");
		Request.instance().setBrandName(getName("Enter clothDryer brand name"));
		Request.instance().setModelName(getName("Enter clothDryer model name"));
		Request.instance().setPrice(getNumberDouble("Enter clothDryer price"));
		Request.instance().setMonthlyRepairPlanCost(getNumberDouble("Enter monthly repair cost"));

		Result result = store.addClothDryer(Request.instance());
		if (result.getResultCode() != Result.OPERATION_COMPLETED) {
			System.out.println("Could not add cloth dryer");
		} else {
			System.out.println("Product added");
		}
//				System.out.println("Brand Name: " + result.getBrandName() + " Model Name: " + result.getModelName()
//						+ " Price: " + result.getPrice() + " Repair Plan: " + result.getMonthlyRepairPlanCost()
//						+ " Cloth Dryer id: " + result.getProductId());
//			}
	}

	/**
	 * Method to be called for adding a cloth washer prompts the user for
	 * appropriate values and uses the appropriate store method for adding the cloth
	 * washer
	 */
	private void addClothWasher() {
		System.out.println("Adding Cloth Washer:");
		Request.instance().setBrandName(getName("Enter brand name"));
		Request.instance().setModelName(getName("Enter model name"));
		Request.instance().setPrice(getNumberDouble("Enter price"));
		Request.instance().setMonthlyRepairPlanCost(getNumberDouble("Enter monthly repair cost"));
		Result result = store.addClothWasher(Request.instance());
		if (result.getResultCode() != Result.OPERATION_COMPLETED) {
			System.out.println("Could not add cloth washer");
		} else {
			System.out.println("Product added");
		}
//				System.out.println("Brand Name: " + result.getBrandName() + " Model Name: " + result.getModelName()
//						+ " Price: " + result.getPrice() + " " + " Repair Plan: " + result.getMonthlyRepairPlanCost()
//						+ " clothWasher id: " + result.getProductId());
//			}
	}

	/**
	 * Method to be called for adding a dish washer prompts the user for appropriate
	 * values and uses the appropriate store method for adding the dish washer
	 */
	private void addDishWasher() {
		System.out.println("Adding Dish Washer:");
		Request.instance().setBrandName(getName("Enter brand name"));
		Request.instance().setModelName(getName("Enter model name"));
		Request.instance().setPrice(getNumberDouble("Enter price"));

		Result result = store.addDishWasher(Request.instance());
		if (result.getResultCode() != Result.OPERATION_COMPLETED) {
			System.out.println("Could not add dish washer ");
		} else {
			System.out.println("Product added");
		}
//				System.out.println("Brand Name: " + result.getBrandName() + " Model Name: " + result.getModelName()
//						+ " Price: $" + result.getPrice() + " Dish Washer id: " + result.getProductId());
//			}
	}

	/**
	 * Method to be called for adding a furnace prompts the user for appropriate
	 * values and uses the appropriate store method for adding the furnace
	 */
	private void addFurnace() {
		System.out.println("Adding Furnace:");
		Request.instance().setBrandName(getName("Enter brand name"));
		Request.instance().setModelName(getName("Enter model name"));
		Request.instance().setPrice(getNumberDouble("Enter price"));
		Request.instance().setBtu(getNumber("Enter btu")); // Ask if BTU is a constant

		Result result = store.addFurnace(Request.instance());
		if (result.getResultCode() != Result.OPERATION_COMPLETED) {
			System.out.println("Could not add furnace");
		} else {
			System.out.println("Product added");
		}
//				System.out.println("Brand Name: " + result.getBrandName() + " Model Name: " + result.getModelName()
//						+ "BTU's: " + result.getBtu() + " furnace id: " + result.getProductId());
//			}
	}

	/**
	 * Method to be called for adding a Kitchen Range prompts the user for
	 * appropriate values and uses the appropriate store method for adding the
	 * kitchen range
	 */
	private void addKitchenRange() {
		System.out.println("Adding Kitchen Range:");
		Request.instance().setBrandName(getName("Enter brand name"));
		Request.instance().setModelName(getName("Enter model name"));
		Request.instance().setPrice(getNumberDouble("Enter price"));

		Result result = store.addKitchenRange(Request.instance());
		if (result.getResultCode() != Result.OPERATION_COMPLETED) {
			System.out.println("Could not add furnace");
		} else {
			System.out.println("Product added");
		}
//				System.out.println(
//						result.getBrandName() + result.getModelName() + "kitchen range id: " + result.getProductId());
//			}
	}

	/**
	 * Method to be called for adding a refrigerator prompts the user for
	 * appropriate values and uses the appropriate store method for adding the
	 * refrigerator
	 */
	private void addRefrigerator() {
		System.out.println("Adding Refrigerator:");
		Request.instance().setBrandName(getName("Enter brand name"));
		Request.instance().setModelName(getName("Enter model name"));
		Request.instance().setPrice(getNumberDouble("Enter price"));
		Request.instance().setCapacity(getNumber("Enter capacity"));

		Result result = store.addRefrigerator(Request.instance());
		if (result.getResultCode() != Result.OPERATION_COMPLETED) {
			System.out.println("Could not add furnace");
		} else {
			System.out.println("Product added");
		}
//				System.out.println(result.getBrandName() + result.getModelName() + "Capacity: " + result.getCapacity()
//						+ " refridgerator id: " + result.getProductId());
//			}
	}

	/**
	 * Method to be called for adding to a product's inventory prompts the user for
	 * appropriate values and uses the appropriate store method for adding to
	 * inventory
	 */
	public void addInventory() {
		Request.instance().setProductId(getToken("Enter Product id"));
		Request.instance().setStock(getNumber("Enter amount to be added"));

		Result result = store.addStock(Request.instance());

		if (result.getResultCode() != Result.OPERATION_COMPLETED) {
			System.out.println("Could not find product");
		} else {
			System.out.println(
					"Success!\nTotal Stock for Product: " + result.getProductId() + " is now " + result.getStock());
		}
	}

	/**
	 * Method to be called for adding a customer. Prompts the user for the
	 * appropriate values and uses the appropriate store method for adding the
	 * customer.
	 * 
	 */
	public void addCustomer() {
		Request.instance().setCustomerName(getName("Enter customer name"));
		Request.instance().setCustomerAddress(getName("Enter address"));
		Request.instance().setCustomerNumber(getName("Enter phone"));
		Result result = store.addCustomer(Request.instance());
		if (result.getResultCode() != Result.OPERATION_COMPLETED) {
			System.out.println("Could not add customer");
		} else {
			System.out.println(result.getCustomerName() + "'s id is " + result.getCustomerId());
		}
	}

	/**
	 * Method to be called for purchasing products. Prompts the user for the
	 * appropriate values and uses the appropriate Store method for purchasing
	 * products.
	 * 
	 */
	public void purchaseProducts() {
		do {
			Request.instance().setCustomerId(getToken("Enter customer id"));
			Request.instance().setProductId(getToken("Enter product id"));
			Request.instance().setPurchaseQuantity(getNumber("Enter quantity of product to purchase"));

			Result result = store.searchCustomer(Request.instance());

			if (result.getResultCode() != Result.OPERATION_COMPLETED) {
				System.out.println("No customer with that id " + Request.instance().getCustomerId());
				return;
			}
			result = store.searchProduct(Request.instance());
			if (result.getResultCode() != Result.OPERATION_COMPLETED) {
				System.out.println("No product with that id " + Request.instance().getProductId());
				return;
			}

			result = store.purchaseProducts(Request.instance());
			String fixedDate = result.getTransactionDate();
			if (result.getResultCode() == Result.OPERATION_COMPLETED && result.getTransactionBackOrder() != null) {
				System.out.println(" Product Id: " + result.getProductId() + ", Purchased by: " + result.getCustomerId()
						+ ",\n Quantity Requested: " + Request.instance().getPurchaseQuantity() + ", Quantity Sold: "
						+ +result.getTransactionQuantity() + ", Total Price: $" + result.getTransactionTotalPrice()
						+ ", Quantity Delivered: " + result.getTransactionDelivered() + ",\n Back Order ID: "
						+ result.getBackOrderId() + ", BackOrder Quantity: " + result.getBackOrderQuantity()
						+ ",\n Purchase Date: " + fixedDate + "\n");
			} else if (result.getResultCode() == Result.OPERATION_COMPLETED
					&& result.getTransactionBackOrder() == null) {
				System.out.println(" Product Id: " + result.getProductId() + ", Purchased by: " + result.getCustomerId()
						+ ",\n Quantity Requested: " + Request.instance().getPurchaseQuantity() + ", Quantity Sold: "
						+ result.getTransactionQuantity() + ", Total Price: $" + result.getTransactionTotalPrice()
						+ ", Quantity Delivered: " + result.getTransactionDelivered() + ",\n Purchase Date: "
						+ result.getTransactionDate() + "\n");
			} else {
				System.out.println("Product could not be purchased. None in stock.");
			}
		} while (yesOrNo("Purchased more products?"));
	}

	/**
	 * Method to be called for printing the revenue which uses the appropriate Store
	 * methods
	 */
	public void printRevenue() {
		double revenueFromSales = 0;
		double revenueFromRepairPlans = 0;
		Iterator<Result> iterator = store.getProducts();
		while (iterator.hasNext()) {
			Result result = iterator.next();
			revenueFromSales += result.getTotalSold() * result.getPrice();
		}
		Iterator<Result> iterator2 = store.getCustomers();
		while (iterator2.hasNext()) {
			Result result = iterator2.next();
			revenueFromRepairPlans += result.getTotalRepairPlansChargedRevenue();
		}
		System.out.println(
				"Revenue: \nSales: $" + revenueFromSales + "\nRepair Plans: $" + revenueFromRepairPlans + "\n");
	}

	/**
	 * Method to be called for displaying transactions. Prompts the user for the
	 * appropriate values and uses the appropriate Store method for displaying
	 * transactions.
	 * 
	 */
	public void getTransactions() {
		Request.instance().setCustomerId(getToken("Enter customer id"));
		Request.instance().setDate(getDate("Please enter the date for which you want records as mm/dd/yy"));
		Iterator<Result> result = store.getTransactions(Request.instance());
		while (result.hasNext()) {
			Result transaction = result.next();
			System.out.println(transaction.getTransactionType() + "   " + transaction.getBrandName()
					+ transaction.getModelName() + "\n");
		}
		System.out.println("\n End of transactions \n");
	}

	/**
	 * Displays all customers including their details, total back orders, and
	 * enrollment in repair plans.
	 */
	public void getCustomers() {
		String inRepairPlan;
		Iterator<Result> iterator = store.getCustomers();
		System.out.println("List of customers:");
		while (iterator.hasNext()) {

			Result result = iterator.next();
			inRepairPlan = " Enrolled in " + result.getRepairPlans().size() + " repair plan(s)";

			System.out.println(" ID: " + result.getCustomerId() + " Name: " + result.getCustomerName() + ", Address: "
					+ result.getCustomerAddress() + ", Phone: " + result.getCustomerNumber() + "\n Total Back Orders: "
					+ result.getCustomerTotalBackOrders() + "\n" + inRepairPlan + "\n");
		}

		System.out.println("End of listing\n");
	}

	/**
	 * Displays all customers with repair plans.
	 */
	public void getCustomersRepairPlans() {
		Iterator<Result> iterator = store.getCustomers();
		System.out.println("List of customers with repair plans (customer name, address, Phone, and id)");
		while (iterator.hasNext()) {
			Result result = iterator.next();
			if (result.getRepairPlans().size() > 0) {
				System.out.println(" Name: " + result.getCustomerName() + ", Address: " + result.getCustomerAddress()
						+ ", Phone: " + result.getCustomerNumber() + ", ID: " + result.getCustomerId()
						+ ",\n Account Repair Plan Balance: " + " " + result.getTotalRepairPlansBalance()
						+ "\n Repair Plans:" + result.getRepairPlans() + "\n");
			}
		}

		System.out.println("End of listing\n");
	}

	/**
	 * Method for enrolling a customer in a repair plan. Prompts for appropriate
	 * data and calls the appropriate Store method.
	 */
	public void enrollInRepairPlan() {
		Request.instance().setCustomerId(getToken("Enter customer id"));
		Request.instance().setProductId(getToken("Enter Product id"));
		Result result = store.enrollInRepairPlan(Request.instance());
		if (result.getResultCode() == Result.PRODUCT_NOT_FOUND) {
			System.out.println("Product Id invalid");
		}
		if (result.getResultCode() == Result.PRODUCT_INVALID) {
			System.out.println("Product does not have a repair plan");
		}
		if (result.getResultCode() == Result.NO_SUCH_CUSTOMER) {
			System.out.println("Customer Id invalid");
		}
		if (result.getResultCode() == Result.OPERATION_COMPLETED) {
			System.out.println("complete");
		}
	}

	/**
	 * Method for withdrawing a customer from a repair plan. Prompts for appropriate
	 * data and calls the appropriate Store method.
	 */
	public void withdrawFromRepairPlan() {
		Request.instance().setCustomerId(getToken("Enter customer id"));
		Request.instance().setProductId(getToken("Enter Product id"));
		Result result = store.withdrawFromRepairPlan(Request.instance());
		if (result.getResultCode() == Result.PRODUCT_NOT_FOUND) {
			System.out.println("Product Id invalid");
		}
		if (result.getResultCode() == Result.PRODUCT_INVALID) {
			System.out.println("Product does not have a repair plan");
		}
		if (result.getResultCode() == Result.NO_SUCH_CUSTOMER) {
			System.out.println("Customer Id invalid");
		}
		if (result.getResultCode() == Result.OPERATION_COMPLETED) {
			System.out.println("complete");
		}
		if (result.getResultCode() == Result.OPERATION_FAILED) {
			System.out.println("No repair plan with these id's");
		}
	}

	/**
	 * Method which calls the Store method for charging all customers with repair
	 * plans
	 */
	public void chargeAllRepairPlans() {
		store.chargeAllRepairPlans();
	}

	/**
	 * Method for printing all the back orders.
	 */
	public void getBackOrders() {
		String satisfied = null;
		Iterator<Result> iterator = store.getBackOrders();
		System.out.println("List of Back Orders:");
		while (iterator.hasNext()) {
			Result result = iterator.next();
			if (result.getBackOrderQuantity() > 0) {
				satisfied = "Not Satisfied";
			} else if (result.getBackOrderQuantity() < 1) {
				satisfied = "Satisfied";
			}

			System.out.println(" ID: " + result.getBackOrderId() + ", Brand: " + result.getBackOrderBrandName()
					+ ", Model: " + result.getBackOrderModelName() + ", Customer Name: "
					+ result.getBackOrderCustomerName() + ", Customer Id: " + result.getBackOrderCustomerId()
					+ ", Quantity: " + result.getBackOrderQuantity() + " " + satisfied);
		}
		System.out.println("\n End of Listing \n");
	}

	/**
	 * Method for fulfilling a single back order.
	 */
	public void fulfillSingleBackOrder() {
		Request.instance().setBackOrderId(getToken("Enter Back Order id"));
		Result result = store.fulfillSingleBackOrder(Request.instance());
		if (result.getResultCode() == Result.PRODUCT_NOT_FOUND) {
			System.out.println("Back Order Id invalid");
		}
		if (result.getResultCode() == Result.PRODUCT_INVALID) {
			System.out.println("Back Order already fulfilled");
		}

		if (result.getResultCode() == Result.OPERATION_FAILED) {
			System.out.println("Back Order not able to be fulfilled. Not enough inventory.");
		}
		if (result.getResultCode() == Result.OPERATION_COMPLETED) {
			System.out.println("Back Order Fulfilled");
		}
	}

	/**
	 * Gets and prints all products.
	 */
	public void getAllProducts() {
		Iterator<Result> iterator = store.getProducts();
		System.out.println("List of products:");
		while (iterator.hasNext()) {
			Result result = iterator.next();
			System.out.println(" Product Id: " + result.getProductId() + ", Brand: " + result.getBrandName()
					+ ", Model: " + result.getModelName() + ", Price: $" + result.getPrice() + ", Inventory: "
					+ result.getStock());
		}
		System.out.println("End of listing\n");
	}

	/**
	 * Gets and prints all of a selected appliance
	 * 
	 * @param selector - selects which appliance to print
	 */
	public void getAllOfSelectedAppliance(int selector) {

		if (selector == 2) {
			Iterator<Result> iterator = store.getProducts();
			System.out.println("List of Cloth Dryers:");
			while (iterator.hasNext()) {
				Result result = iterator.next();
				if ((result.getProductId().substring(0, 2)).equals("CD")) {
					System.out.println(" Product Id: " + result.getProductId() + ", Brand: " + result.getBrandName()
							+ ", Model: " + result.getModelName() + ", Price: $" + result.getPrice() + ", Inventory: "
							+ result.getStock());
				}
			}
			System.out.println("End of listing\n");
		}
		if (selector == 3) {
			Iterator<Result> iterator = store.getProducts();
			System.out.println("List of Cloth Washers:");
			while (iterator.hasNext()) {
				Result result = iterator.next();
				if ((result.getProductId().substring(0, 2)).equals("CW")) {
					System.out.println(" Product Id: " + result.getProductId() + ", Brand: " + result.getBrandName()
							+ ", Model: " + result.getModelName() + ", Price: $" + result.getPrice() + ", Inventory: "
							+ result.getStock());
				}
			}
			System.out.println("End of listing");
		}
		if (selector == 4) {
			Iterator<Result> iterator = store.getProducts();
			System.out.println("List of Dish Washers:");
			while (iterator.hasNext()) {
				Result result = iterator.next();
				if ((result.getProductId().substring(0, 2)).equals("DW")) {
					System.out.println(" Product Id: " + result.getProductId() + ", Brand: " + result.getBrandName()
							+ ", Model: " + result.getModelName() + ", Price: $" + result.getPrice() + ", Inventory: "
							+ result.getStock());
				}
			}
			System.out.println("End of listing\n");
		}
		if (selector == 5) {
			Iterator<Result> iterator = store.getProducts();
			System.out.println("List of Furnaces:");
			while (iterator.hasNext()) {
				Result result = iterator.next();
				if ((result.getProductId().substring(0, 1)).equals("F")) {
					System.out.println(" Product Id: " + result.getProductId() + ", Brand: " + result.getBrandName()
							+ ", Model: " + result.getModelName() + ", Price: $" + result.getPrice() + ", Inventory: "
							+ result.getStock());
				}
			}
			System.out.println("End of listing");
		}
		if (selector == 6) {
			Iterator<Result> iterator = store.getProducts();
			System.out.println("List of Kitchen Ranges:");
			while (iterator.hasNext()) {
				Result result = iterator.next();
				if ((result.getProductId().substring(0, 2)).equals("KR")) {
					System.out.println(" Product Id: " + result.getProductId() + ", Brand: " + result.getBrandName()
							+ ", Model: " + result.getModelName() + ", Price: $" + result.getPrice() + ", Inventory: "
							+ result.getStock());
				}
			}
			System.out.println("End of listing");
		}
		if (selector == 7) {
			Iterator<Result> iterator = store.getProducts();
			System.out.println("List of Refridgerators:");
			while (iterator.hasNext()) {
				Result result = iterator.next();
				if (result.getProductId().substring(0, 1).equals("R")) {
					System.out.println(" Product Id: " + result.getProductId() + ", Brand: " + result.getBrandName()
							+ ", Model: " + result.getModelName() + ", Price: $" + result.getPrice() + ", Inventory: "
							+ result.getStock());
				}
			}
			System.out.println("End of listing\n");
		}
	}

	/**
	 * Method to be called for saving the Store object. Uses the appropriate Store
	 * method for saving.
	 * 
	 */
	private void save() {
		if (Store.save()) {
			System.out.println(" The store has been successfully saved in the file StoreData \n");
		} else {
			System.out.println(" There has been an error in saving \n");
		}
	}

	/**
	 * Method to be called for retrieving saved data. Uses the appropriate Store
	 * method for retrieval.
	 * 
	 */
	private void retrieve() {
		try {
			if (store == null) {
				store = Store.retrieve();
				if (store != null) {
					System.out.println(" The store data has been successfully retrieved from the file StoreData \n");
				} else {
					System.out.println("File doesnt exist; creating new store data");
					store = Store.instance();
				}
			}
		} catch (Exception cnfe) {
			cnfe.printStackTrace();
		}
	}

	/**
	 * begins the user interface
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		UserInterface.instance().processMainMenu();
	}

}
